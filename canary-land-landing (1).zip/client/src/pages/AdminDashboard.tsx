import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { Loader2, Edit2, CheckCircle, Clock, AlertCircle, Users, PawPrint, Gift, Trash2, Plus } from "lucide-react";
import { toast } from "sonner";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

export default function AdminDashboard() {
  const { user, loading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<"grooming" | "boarding" | "customers" | "pets" | "points">("grooming");
  const [selectedBooking, setSelectedBooking] = useState<any>(null);
  const [editingBooking, setEditingBooking] = useState<any>(null);
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [pointsToAdd, setPointsToAdd] = useState<number>(0);
  const [pointsReason, setPointsReason] = useState<string>("");
  const [newPetForm, setNewPetForm] = useState({ name: "", type: "", breed: "", age: "", notes: "" });
  const [isAwardingPoints, setIsAwardingPoints] = useState(false);

  // Fetch grooming bookings
  const groomingBookingsQuery = trpc.admin.getGroomingBookings.useQuery(undefined, {
    enabled: !!user,
  });

  // Fetch pet boarding bookings
  const petBoardingBookingsQuery = trpc.admin.getPetBoardingBookings.useQuery(undefined, {
    enabled: !!user,
  });

  // Fetch customers with loyalty points
  const customersWithPointsQuery = trpc.admin.getAllCustomersWithPoints.useQuery(undefined, {
    enabled: !!user && activeTab === "points",
  });

  // Update grooming booking mutation
  const updateGroomingMutation = trpc.admin.updateGroomingBooking.useMutation({
    onSuccess: () => {
      toast.success("Grooming booking updated successfully!");
      groomingBookingsQuery.refetch();
      setEditingBooking(null);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update booking");
    },
  });

  // Update pet boarding booking mutation
  const updatePetBoardingMutation = trpc.admin.updatePetBoardingBooking.useMutation({
    onSuccess: () => {
      toast.success("Pet boarding booking updated successfully!");
      petBoardingBookingsQuery.refetch();
      setEditingBooking(null);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update booking");
    },
  });

  // Award loyalty points mutation
  const awardPointsMutation = trpc.admin.awardPoints.useMutation({
    onSuccess: (data) => {
      toast.success(data.message);
      setPointsToAdd(0);
      setPointsReason("");
      setSelectedCustomer(null);
      // Refetch customers to update loyalty points display
      groomingBookingsQuery.refetch();
      petBoardingBookingsQuery.refetch();
      customersWithPointsQuery.refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to award points");
    },
  });

  if (authLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navigation />
        <main className="flex-1 container py-24 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </main>
        <Footer />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navigation />
        <main className="flex-1 container py-24">
          <div className="text-center space-y-4">
            <h1 className="text-4xl font-bold text-primary">Access Denied</h1>
            <p className="text-muted-foreground">You must be logged in to access the admin dashboard.</p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const groomingBookings = groomingBookingsQuery.data || [];
  const petBoardingBookings = petBoardingBookingsQuery.data || [];

  // Extract unique customers from bookings
  const customers = Array.from(new Map(
    [...groomingBookings, ...petBoardingBookings].map(booking => [
      booking.customerName,
      {
        name: booking.customerName,
        phone: booking.customerPhone,
        email: booking.customerEmail || "N/A",
        totalBookings: [...groomingBookings, ...petBoardingBookings].filter(b => b.customerName === booking.customerName).length,
        pets: Array.from(new Set([...groomingBookings, ...petBoardingBookings]
          .filter(b => b.customerName === booking.customerName)
          .map(b => `${b.petName} (${b.petType})`)
        ))
      }
    ])
  ).values());

  // Extract unique pets from bookings
  const pets = Array.from(new Map(
    [...groomingBookings, ...petBoardingBookings].map(booking => [
      `${booking.petName}-${booking.petType}`,
      {
        name: booking.petName,
        type: booking.petType,
        breed: booking.petBreed || "Unknown",
        owner: booking.customerName,
        totalBookings: [...groomingBookings, ...petBoardingBookings].filter(b => b.petName === booking.petName).length,
      }
    ])
  ).values());

  const handleUpdateBooking = async () => {
    if (!editingBooking) return;

    if (activeTab === "grooming") {
      await updateGroomingMutation.mutateAsync({
        slipNumber: editingBooking.slipNumber,
        status: editingBooking.status,
        groomer: editingBooking.groomer,
        specialNotes: editingBooking.specialNotes,
      });
    } else {
      await updatePetBoardingMutation.mutateAsync({
        slipNumber: editingBooking.slipNumber,
        status: editingBooking.status,
        specialNotes: editingBooking.specialNotes,
      });
    }
  };

  const handleAwardPoints = async () => {
    if (!selectedCustomer) {
      toast.error("Please select a customer");
      return;
    }
    if (pointsToAdd <= 0) {
      toast.error("Please enter a valid number of points");
      return;
    }
    if (!pointsReason.trim()) {
      toast.error("Please provide a reason for awarding points");
      return;
    }

    setIsAwardingPoints(true);
    try {
      await awardPointsMutation.mutateAsync({
        customerName: selectedCustomer.name,
        points: pointsToAdd,
        reason: pointsReason,
      });
    } finally {
      setIsAwardingPoints(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Confirmed":
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case "Scheduled":
        return <Clock className="w-5 h-5 text-blue-500" />;
      case "Pending":
        return <AlertCircle className="w-5 h-5 text-yellow-500" />;
      default:
        return <Clock className="w-5 h-5 text-gray-500" />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      <main className="flex-1 container py-12">
        <div className="space-y-8">
          {/* Header */}
          <div className="space-y-2">
            <h1 className="text-4xl font-bold text-primary">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage bookings, customers, pets, and loyalty points</p>
          </div>

          {/* Tabs */}
          <div className="flex gap-2 border-b border-border overflow-x-auto">
            <button
              onClick={() => setActiveTab("grooming")}
              className={`px-4 py-2 font-medium transition-colors whitespace-nowrap ${
                activeTab === "grooming"
                  ? "text-primary border-b-2 border-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Pet Grooming ({groomingBookings.length})
            </button>
            <button
              onClick={() => setActiveTab("boarding")}
              className={`px-4 py-2 font-medium transition-colors whitespace-nowrap ${
                activeTab === "boarding"
                  ? "text-primary border-b-2 border-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Pet Boarding ({petBoardingBookings.length})
            </button>
            <button
              onClick={() => setActiveTab("customers")}
              className={`px-4 py-2 font-medium transition-colors whitespace-nowrap flex items-center gap-2 ${
                activeTab === "customers"
                  ? "text-primary border-b-2 border-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Users className="w-4 h-4" />
              Customers ({customers.length})
            </button>
            <button
              onClick={() => setActiveTab("pets")}
              className={`px-4 py-2 font-medium transition-colors whitespace-nowrap flex items-center gap-2 ${
                activeTab === "pets"
                  ? "text-primary border-b-2 border-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <PawPrint className="w-4 h-4" />
              Pet Records ({pets.length})
            </button>
            <button
              onClick={() => setActiveTab("points")}
              className={`px-4 py-2 font-medium transition-colors whitespace-nowrap flex items-center gap-2 ${
                activeTab === "points"
                  ? "text-primary border-b-2 border-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Gift className="w-4 h-4" />
              Loyalty Points
            </button>
          </div>

          {/* Grooming Bookings */}
          {activeTab === "grooming" && (
            <div className="space-y-4">
              {groomingBookingsQuery.isLoading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              ) : groomingBookings.length === 0 ? (
                <Card className="p-8 text-center">
                  <p className="text-muted-foreground">No grooming bookings yet</p>
                </Card>
              ) : (
                groomingBookings.map((booking: any) => (
                  <Card key={booking.slipNumber} className="p-6 space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          {getStatusIcon(booking.status)}
                          <h3 className="text-lg font-semibold">{booking.slipNumber}</h3>
                          <span className={`px-2 py-1 rounded text-sm font-medium ${
                            booking.status === "Confirmed" ? "bg-green-100 text-green-800" :
                            booking.status === "Scheduled" ? "bg-blue-100 text-blue-800" :
                            "bg-yellow-100 text-yellow-800"
                          }`}>
                            {booking.status}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {booking.customerName} • {booking.petName} ({booking.petType})
                        </p>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setEditingBooking(booking)}
                      >
                        <Edit2 className="w-4 h-4 mr-2" />
                        Edit
                      </Button>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Date & Time</p>
                        <p className="font-medium">{new Date(booking.appointmentDate).toLocaleDateString()} at {booking.appointmentTime}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Service</p>
                        <p className="font-medium">{booking.service}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Phone</p>
                        <p className="font-medium">{booking.customerPhone}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Groomer</p>
                        <p className="font-medium">{booking.groomer || "Not assigned"}</p>
                      </div>
                    </div>

                    {booking.specialNotes && (
                      <div className="bg-muted p-3 rounded">
                        <p className="text-sm text-muted-foreground">Special Notes</p>
                        <p className="text-sm">{booking.specialNotes}</p>
                      </div>
                    )}
                  </Card>
                ))
              )}
            </div>
          )}

          {/* Pet Boarding Bookings */}
          {activeTab === "boarding" && (
            <div className="space-y-4">
              {petBoardingBookingsQuery.isLoading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              ) : petBoardingBookings.length === 0 ? (
                <Card className="p-8 text-center">
                  <p className="text-muted-foreground">No pet boarding bookings yet</p>
                </Card>
              ) : (
                petBoardingBookings.map((booking: any) => (
                  <Card key={booking.slipNumber} className="p-6 space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          {getStatusIcon(booking.status)}
                          <h3 className="text-lg font-semibold">{booking.slipNumber}</h3>
                          <span className={`px-2 py-1 rounded text-sm font-medium ${
                            booking.status === "Confirmed" ? "bg-green-100 text-green-800" :
                            booking.status === "Scheduled" ? "bg-blue-100 text-blue-800" :
                            "bg-yellow-100 text-yellow-800"
                          }`}>
                            {booking.status}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {booking.customerName} • {booking.petName} ({booking.petType})
                        </p>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setEditingBooking(booking)}
                      >
                        <Edit2 className="w-4 h-4 mr-2" />
                        Edit
                      </Button>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Check-In</p>
                        <p className="font-medium">{new Date(booking.checkInDate).toLocaleDateString()}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Check-Out</p>
                        <p className="font-medium">{new Date(booking.checkOutDate).toLocaleDateString()}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Total Price</p>
                        <p className="font-medium">AED {booking.totalPrice}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Phone</p>
                        <p className="font-medium">{booking.customerPhone}</p>
                      </div>
                    </div>

                    {booking.specialNotes && (
                      <div className="bg-muted p-3 rounded">
                        <p className="text-sm text-muted-foreground">Special Notes</p>
                        <p className="text-sm">{booking.specialNotes}</p>
                      </div>
                    )}
                  </Card>
                ))
              )}
            </div>
          )}

          {/* Customers Tab */}
          {activeTab === "customers" && (
            <div className="space-y-4">
              {customers.length === 0 ? (
                <Card className="p-8 text-center">
                  <p className="text-muted-foreground">No customers yet</p>
                </Card>
              ) : (
                customers.map((customer: any) => (
                  <Card key={customer.name} className="p-6 space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <h3 className="text-lg font-semibold">{customer.name}</h3>
                        <p className="text-sm text-muted-foreground">{customer.phone}</p>
                        <p className="text-sm text-muted-foreground">{customer.email}</p>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedCustomer(customer)}
                      >
                        View Details
                      </Button>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Total Bookings</p>
                        <p className="font-medium">{customer.totalBookings}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Pets</p>
                        <p className="font-medium">{customer.pets.length}</p>
                      </div>
                    </div>

                    {customer.pets.length > 0 && (
                      <div className="bg-muted p-3 rounded">
                        <p className="text-sm text-muted-foreground mb-2">Pets</p>
                        <div className="space-y-1">
                          {customer.pets.map((pet: string) => (
                            <p key={pet} className="text-sm">{pet}</p>
                          ))}
                        </div>
                      </div>
                    )}
                  </Card>
                ))
              )}
            </div>
          )}

          {/* Pet Records Tab */}
          {activeTab === "pets" && (
            <div className="space-y-4">
              {pets.length === 0 ? (
                <Card className="p-8 text-center">
                  <p className="text-muted-foreground">No pets registered yet</p>
                </Card>
              ) : (
                pets.map((pet: any) => (
                  <Card key={`${pet.name}-${pet.type}`} className="p-6 space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <h3 className="text-lg font-semibold">{pet.name}</h3>
                        <p className="text-sm text-muted-foreground">Owner: {pet.owner}</p>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                      >
                        <Edit2 className="w-4 h-4 mr-2" />
                        Edit
                      </Button>
                    </div>

                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Type</p>
                        <p className="font-medium">{pet.type}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Breed</p>
                        <p className="font-medium">{pet.breed}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Total Bookings</p>
                        <p className="font-medium">{pet.totalBookings}</p>
                      </div>
                    </div>
                  </Card>
                ))
              )}
            </div>
          )}

          {/* Loyalty Points Tab */}
          {activeTab === "points" && (
            <div className="space-y-4">
              <Card className="p-6 space-y-4">
                <h3 className="text-lg font-semibold">Award Loyalty Points</h3>
                <div className="space-y-4">
                  <div>
                    <Label>Select Customer</Label>
                    <Select value={selectedCustomer?.name || ""} onValueChange={(value) => {
                      const customer = customers.find((c: any) => c.name === value);
                      setSelectedCustomer(customer);
                    }}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a customer" />
                      </SelectTrigger>
                      <SelectContent>
                        {customers.map((customer: any) => (
                          <SelectItem key={customer.name} value={customer.name}>
                            {customer.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Points to Award</Label>
                    <Input
                      type="number"
                      value={pointsToAdd}
                      onChange={(e) => setPointsToAdd(parseInt(e.target.value) || 0)}
                      placeholder="Enter points"
                    />
                  </div>
                  <div>
                    <Label>Reason</Label>
                    <Textarea
                      value={pointsReason}
                      onChange={(e) => setPointsReason(e.target.value)}
                      placeholder="Why are you awarding these points?"
                    />
                  </div>
                  <Button 
                    className="w-full" 
                    onClick={handleAwardPoints}
                    disabled={isAwardingPoints || awardPointsMutation.isPending}
                  >
                    {isAwardingPoints || awardPointsMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Awarding Points...
                      </>
                    ) : (
                      <>
                        <Plus className="w-4 h-4 mr-2" />
                        Award Points
                      </>
                    )}
                  </Button>
                </div>
              </Card>

              <Card className="p-6 space-y-4">
                <h3 className="text-lg font-semibold">Customer Loyalty Points</h3>
                {customersWithPointsQuery.isLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-primary" />
                  </div>
                ) : (
                  <div className="space-y-2">
                    {(customersWithPointsQuery.data || []).map((customer: any) => {
                      const pointsBalance = customer.loyaltyPoints?.currentBalance || 0;
                      return (
                        <div key={customer.id} className="flex items-center justify-between p-3 border rounded hover:bg-muted/50 transition-colors">
                          <div>
                            <p className="font-medium">{customer.name}</p>
                            <p className="text-sm text-muted-foreground">{customer.totalBookings} bookings</p>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-primary">{pointsBalance} Points</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </Card>
            </div>
          )}
        </div>
      </main>

      {/* Edit Booking Dialog */}
      <Dialog open={!!editingBooking} onOpenChange={(open) => !open && setEditingBooking(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Booking</DialogTitle>
            <DialogDescription>
              Update booking details for {editingBooking?.slipNumber}
            </DialogDescription>
          </DialogHeader>
          {editingBooking && (
            <div className="space-y-4">
              <div>
                <Label>Status</Label>
                <Select value={editingBooking.status} onValueChange={(value) => setEditingBooking({...editingBooking, status: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Confirmed">Confirmed</SelectItem>
                    <SelectItem value="Scheduled">Scheduled</SelectItem>
                    <SelectItem value="Pending">Pending</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {activeTab === "grooming" && (
                <>
                  <div>
                    <Label>Groomer</Label>
                    <Input
                      value={editingBooking.groomer || ""}
                      onChange={(e) => setEditingBooking({...editingBooking, groomer: e.target.value})}
                      placeholder="Groomer name"
                    />
                  </div>
                </>
              )}
              <div>
                <Label>Special Notes</Label>
                <Textarea
                  value={editingBooking.specialNotes || ""}
                  onChange={(e) => setEditingBooking({...editingBooking, specialNotes: e.target.value})}
                  placeholder="Add any special notes"
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={() => setEditingBooking(null)}>
                  Cancel
                </Button>
                <Button onClick={handleUpdateBooking} disabled={updateGroomingMutation.isPending || updatePetBoardingMutation.isPending}>
                  {updateGroomingMutation.isPending || updatePetBoardingMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    "Save Changes"
                  )}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
}
