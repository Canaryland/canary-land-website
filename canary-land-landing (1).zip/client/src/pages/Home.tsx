/**
 * Canary Land Pet Shop Landing Page
 * Design: Organic Modernism - biophilic design with natural curves, flowing transitions
 * Color Palette: Forest greens, terracotta, sandy beige, canary yellow
 * Typography: Comfortaa (display) + Nunito (body)
 */

import HeroSection from "@/components/HeroSection";
import ServicesSection from "@/components/ServicesSection";
import AdditionalServicesSection from "@/components/AdditionalServicesSection";
import GoogleReviewsCarousel from "@/components/GoogleReviewsCarousel";
import TestimonialsSection from "@/components/TestimonialsSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import Navigation from "@/components/Navigation";

export default function Home() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <main>
        <HeroSection />
        <ServicesSection />
        <AdditionalServicesSection />
        <GoogleReviewsCarousel />
        <TestimonialsSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}
