/**
 * Service Detail Page - Organic Modernism Design
 * Individual service pages with full descriptions and booking
 */

import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Check } from "lucide-react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import GroomingBookingForm from "@/components/GroomingBookingForm";
import PetBoardingBookingForm from "@/components/PetBoardingBookingForm";

const servicesData: Record<string, any> = {
  "pet-grooming": {
    title: "Pet Grooming",
    icon: "✂️",
    description: "Professional grooming services to keep your pets looking and feeling their best",
    fullDescription: "Our expert groomers provide comprehensive grooming services for all pet types. From basic baths and nail trims to full grooming packages, we ensure your pets look and feel amazing.",
    image: "https://private-us-east-1.manuscdn.com/sessionFile/qTkRH805vxXtWV3kFm7uhM/sandbox/KuqxptX1C71NrJGq8l4CrZ-img-3_1770821374000_na1fn_cGV0LWdyb29taW5nLXNlcnZpY2U.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvcVRrUkg4MDV2eFh0V1Yza0ZtN3VoTS9zYW5kYm94L0t1cXhwdFgxQzcxTnJKR3E4bDRDclotaW1nLTNfMTc3MDgyMTM3NDAwMF9uYTFmbl9jR1YwTFdkeWIyOXRhVzVuTFhObGNuWnBZMlUucG5nP3gtb3NzLXByb2Nlc3M9aW1hZ2UvcmVzaXplLHdfMTkyMCxoXzE5MjAvZm9ybWF0LHdlYnAvcXVhbGl0eSxxXzgwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=FYCpLqAMxbb79oi625uttJ6jGLUQB9ofos~8qdb4gwBjgtnPMKKVa59zqjBRgbC0wqBV2ZPPdGhDIWh5KcTEQ8RO1aQytVe2Vmov3Q95-Ncsrh2jNSSExCHLzKKK3Od6QOxRbaBPwlP3-VcNGoSg0b3b-QD4NkYTkGFjXnhWMmqOi5dZkio8hBbs9YIb011iEhNsIcc-VRO~TA~EjO-PGDns5mLN6n6FuP-~cjMRTu8ntXs95W-u5BRHap11XcfreKSF0B5TgZrlS-sR1ajSxLwHumRZWoHrSyKLABEaC7csnqyad5PfhzUdOOjCzQ1AcJP-9UeWeH7XsE8jspgqZA__",
    benefits: [
      "Professional grooming by experienced staff",
      "Safe and comfortable environment",
      "Customized grooming packages",
      "Health checks during grooming",
      "Nail trimming and ear cleaning",
      "Dental care options available"
    ],
    pricing: "Starting from AED 40",
    duration: "",
    showPricingTable: true,
    showBookingForm: true,
    pricingTable: [
      { category: "Full Grooming - Cat", size: "Small", price: "AED 150", description: "Cut Nail, Ear cleaning, Cut hair/Stylish, Bath w/ Conditioner, Brush Teeth, Pads Shaving, Sanitary Hair Cut, Eye Clean, Pets Spray, Fur Combing & Brushing, Blow Drying" },
      { category: "Full Grooming - Cat", size: "Medium", price: "AED 200", description: "Cut Nail, Ear cleaning, Cut hair/Stylish, Bath w/ Conditioner, Brush Teeth, Pads Shaving, Sanitary Hair Cut, Eye Clean, Pets Spray, Fur Combing & Brushing, Blow Drying" },
      { category: "Full Grooming - Cat", size: "Large", price: "AED 280", description: "Cut Nail, Ear cleaning, Cut hair/Stylish, Bath w/ Conditioner, Brush Teeth, Pads Shaving, Sanitary Hair Cut, Eye Clean, Pets Spray, Fur Combing & Brushing, Blow Drying" },
      { category: "Full Grooming - Dog", size: "Small", price: "AED 180", description: "Cut Nail, Ear cleaning, Cut hair/Stylish, Full Shaving, Bath w/ Conditioner, Brush Teeth, Pads Shaving, Sanitary Hair Cut, Eye Clean, Pets Spray, Fur Combing & Brushing, Blow Drying" },
      { category: "Full Grooming - Dog", size: "Medium", price: "AED 250", description: "Cut Nail, Ear cleaning, Cut hair/Stylish, Full Shaving, Bath w/ Conditioner, Brush Teeth, Pads Shaving, Sanitary Hair Cut, Eye Clean, Pets Spray, Fur Combing & Brushing, Blow Drying" },
      { category: "Full Grooming - Dog", size: "Large", price: "AED 350", description: "Cut Nail, Ear cleaning, Cut hair/Stylish, Full Shaving, Bath w/ Conditioner, Brush Teeth, Pads Shaving, Sanitary Hair Cut, Eye Clean, Pets Spray, Fur Combing & Brushing, Blow Drying" },
      { category: "Full Grooming - Bird/Rabbit", size: "All Size", price: "AED 100", description: "Cut Nail, Ear Cleaning, Eye Cleaning, De Shedding, Fur Cleaning, Combing & Brushing, Pet Spray, Cut Wings" },
      { category: "Basic Grooming", size: "Small", price: "AED 80", description: "Cut Nail, Ear cleaning, Pads Shaving, Eye Clean, Pets Spray, Fur Combing & Brushing, Blow Drying" },
      { category: "Basic Grooming", size: "Medium", price: "AED 120", description: "Cut Nail, Ear cleaning, Pads Shaving, Eye Clean, Pets Spray, Fur Combing & Brushing, Blow Drying" },
      { category: "Basic Grooming", size: "Large", price: "AED 150", description: "Cut Nail, Ear cleaning, Pads Shaving, Eye Clean, Pets Spray, Fur Combing & Brushing, Blow Drying" },
      { category: "Basic Grooming - Bird", size: "All Size", price: "AED 40", description: "Cut Nail, Cut Wings Feather, Grinding Pointed Beak" },
      { category: "Express Bath - Dog", size: "Small", price: "AED 85", description: "Quick bath with standard shampoo, Conditioner, blow dry, light brushing" },
      { category: "Express Bath - Dog", size: "Medium", price: "AED 130", description: "Quick bath with standard shampoo, Conditioner, blow dry, light brushing" },
      { category: "Express Bath - Dog", size: "Large", price: "AED 150", description: "Quick bath with standard shampoo, Conditioner, blow dry, light brushing" },
      { category: "Express Bath - Cat", size: "All Size", price: "AED 80", description: "Quick bath with standard shampoo, Conditioner, blow dry, light brushing" },
      { category: "Nail Cut - Dog", size: "All Size", price: "AED 45", description: "Quick and gentle nail trimming service" },
      { category: "Nail Cut - Cat", size: "All Size", price: "AED 35", description: "Quick and gentle nail trimming service" },
      { category: "Add-on: Teeth Brushing/Nail Cut", size: "All Type", price: "AED 50", description: "Pet-safe teeth brushing for fresh breath" },
      { category: "Add-on: De-shedding Treatment", size: "All Type", price: "AED 130", description: "Special treatment to reduce shedding" },
      { category: "Add-on: Medicated Bath - Cat", size: "All Size", price: "AED 150", description: "Gentle medicated grooming bath" },
      { category: "Add-on: Medicated Bath - Dog", size: "Small", price: "AED 150", description: "Gentle medicated grooming bath" },
      { category: "Add-on: Medicated Bath - Dog", size: "Medium", price: "AED 200", description: "Gentle medicated grooming bath" },
      { category: "Add-on: Medicated Bath - Dog", size: "Large", price: "AED 250", description: "Gentle medicated grooming bath" }
    ]
  },
  "pet-boarding": {
    title: "Pet Boarding",
    icon: "🏠",
    description: "Safe, comfortable boarding facilities for your beloved companions",
    fullDescription: "Leave your pets in safe hands while you travel. Our boarding facilities provide comfortable accommodations, regular feeding, playtime, and 24/7 supervision.",
    image: "https://images.unsplash.com/photo-1548681528-6a5c45b66b42?w=800&auto=format&fit=crop",
    benefits: [
      "Spacious and comfortable rooms",
      "Regular feeding and playtime",
      "24/7 supervision and monitoring",
      "Daily updates and photos",
      "Veterinary care available",
      "Special diet accommodations"
    ],
    pricing: "AED 50 per day",
    duration: "Flexible - daily, weekly, or monthly",
    showBookingForm: true
  },
  "animal-trading": {
    title: "Animal Trading",
    icon: "🦜",
    description: "Exotic birds and unique pets from trusted sources",
    fullDescription: "Discover a wide variety of exotic birds and unique pets from trusted and ethical sources. All animals are healthy, vaccinated, and come with proper documentation.",
    image: "https://private-us-east-1.manuscdn.com/sessionFile/qTkRH805vxXtWV3kFm7uhM/sandbox/KuqxptX1C71NrJGq8l4CrZ-img-5_1770821370000_na1fn_ZXhvdGljLWJpcmRzLWNvbGxlY3Rpb24.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvcVRrUkg4MDV2eFh0V1Yza0ZtN3VoTS9zYW5kYm94L0t1cXhwdFgxQzcxTnJKR3E4bDRDclotaW1nLTVfMTc3MDgyMTM3MDAwMF9uYTFmbl9aWGh2ZEdsakxXSnBjbVJ6TFdOdmJHeGxZM1JwYjI0LnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=qH3YhiEEv8RWHEZDUX5r5xtteZnzjYM59fPybKbnBEjaa0zMFtdhOgSBGegaax5g0mAVV0YWeZyUfcYIyWOFRh~nQrXHhEpXJtM298BP6xYPdqkbT00jwbDozYdynmyONm9DCVhU0v9gpO~xQ~nid6pq1GKO~Oa~fKK2wIZpw90vwzzhoJjxgASxfIPtrnVjoDvI86GWIcz7O36cO-FZYOwGWPQ-lfIJqHiwUltbE9ImnwTxHDEWbfblSBD9RV1om8SCK4qBNEhtUPORMYoVJierqFe3zsNAglG4hpRWcvEI2hyXym913Cw-FOHFVeZahBtkEoq62xSkd43BkknEUA__",
    benefits: [
      "Wide variety of exotic birds",
      "Healthy and vaccinated animals",
      "Proper documentation and certificates",
      "Expert advice on pet care",
      "Ethical sourcing practices",
      "Lifetime support for pet owners"
    ],
    pricing: "Varies by species",
    duration: "Available year-round"
  },
  "aquatic-animals": {
    title: "Aquatic Animals",
    icon: "🐠",
    description: "Complete aquarium solutions and beautiful aquatic life",
    fullDescription: "Explore our stunning collection of aquatic animals and complete aquarium setups. From freshwater fish to saltwater species, we provide everything for a thriving aquarium.",
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663347663075/sMhGugEsXeNbPPgg.jpg",
    benefits: [
      "Wide selection of fish species",
      "Aquarium setup and design",
      "Aquatic plants and decorations",
      "Filtration and maintenance systems",
      "Water testing and treatment",
      "Expert aquarium care advice"
    ],
    pricing: "Starting from AED 50 per fish",
    duration: "Available year-round"
  },
  "pet-food-supply": {
    title: "Pet Food & Supply",
    icon: "🛍️",
    description: "Premium pet food and all the supplies your pets need",
    fullDescription: "Stock up on premium pet food, toys, accessories, and supplies for all your pets. We carry trusted brands and offer competitive prices.",
    image: "https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=800&auto=format&fit=crop",
    benefits: [
      "Premium quality pet food",
      "Wide range of pet supplies",
      "Toys and enrichment items",
      "Health supplements",
      "Competitive pricing",
      "Home delivery available"
    ],
    pricing: "Varies by product",
    duration: "Available year-round"
  }
};

export default function ServiceDetail() {
  const params = useParams();
  const [, navigate] = useLocation();
  const serviceId = params.id as string;
  const service = servicesData[serviceId];

  if (!service) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navigation />
        <main className="flex-1 container py-24">
          <div className="text-center space-y-4">
            <h1 className="text-4xl font-bold text-primary">Service Not Found</h1>
            <p className="text-muted-foreground">The service you're looking for doesn't exist.</p>
            <Button onClick={() => navigate("/")} className="mt-4">
              Back to Home
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="pt-32 pb-16 bg-gradient-to-b from-primary/5 to-background">
          <div className="container">
            <button
              onClick={() => navigate("/")}
              className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors mb-8 font-medium"
            >
              <ArrowLeft className="w-5 h-5" />
              Back to Services
            </button>
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <span className="text-6xl">{service.icon}</span>
                  <h1 className="text-5xl font-bold text-primary">{service.title}</h1>
                </div>
                <p className="text-xl text-muted-foreground leading-relaxed">
                  {service.fullDescription}
                </p>
                <div className="space-y-3 pt-4">
                  <p className="text-lg font-semibold text-primary">
                    {service.pricing}
                  </p>
                  {service.duration && (
                    <p className="text-muted-foreground">
                      Duration: {service.duration}
                    </p>
                  )}
                </div>
              </div>
              <div className="rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src={service.image}
                  alt={service.title}
                  className="w-full h-96 object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Pricing Table Section for Pet Grooming */}
        {service.showPricingTable && (
          <section className="py-24 bg-background">
            <div className="container">
              <h2 className="text-4xl font-bold text-primary mb-12">Our Pricing</h2>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-primary/10 border-b-2 border-primary">
                      <th className="px-6 py-4 text-left font-bold text-primary">Service</th>
                      <th className="px-6 py-4 text-left font-bold text-primary">Size</th>
                      <th className="px-6 py-4 text-left font-bold text-primary">Price</th>
                      <th className="px-6 py-4 text-left font-bold text-primary">Description</th>
                    </tr>
                  </thead>
                  <tbody>
                    {service.pricingTable.map((item: any, index: number) => (
                      <tr
                        key={index}
                        className={`border-b border-border hover:bg-primary/5 transition-colors ${
                          index % 2 === 0 ? "bg-background" : "bg-muted/30"
                        }`}
                      >
                        <td className="px-6 py-4 font-semibold text-foreground">{item.category}</td>
                        <td className="px-6 py-4 text-muted-foreground">{item.size}</td>
                        <td className="px-6 py-4 font-bold text-primary text-lg">{item.price}</td>
                        <td className="px-6 py-4 text-muted-foreground text-sm">{item.description}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
        )}

        {/* Booking Form Section */}
        {service.showBookingForm && (
          <section className="py-24 bg-primary/5">
            <div className="container max-w-3xl">
              {serviceId === "pet-grooming" && (
                <GroomingBookingForm service={service.title} />
              )}
              {serviceId === "pet-boarding" && (
                <PetBoardingBookingForm service={service.title} />
              )}
            </div>
          </section>
        )}

        {/* Benefits Section */}
        {!service.showPricingTable && (
          <section className="py-24 bg-background">
            <div className="container">
              <h2 className="text-4xl font-bold text-primary mb-12">What's Included</h2>
              <div className="grid md:grid-cols-2 gap-6">
                {service.benefits.map((benefit: string, index: number) => (
                  <Card key={index} className="p-6 border-2 border-border hover:border-primary transition-colors">
                    <div className="flex items-start gap-4">
                      <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-1">
                        <Check className="w-5 h-5 text-primary" />
                      </div>
                      <p className="text-lg text-foreground">{benefit}</p>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* CTA Section */}
        {!service.showBookingForm && (
          <section className="py-24 bg-primary text-primary-foreground">
            <div className="container text-center space-y-8">
              <h2 className="text-4xl font-bold">Ready to Get Started?</h2>
              <p className="text-xl max-w-2xl mx-auto opacity-90">
                Contact us today to book this service or learn more about how we can help your pets.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  onClick={() => navigate("/#contact")}
                  className="bg-primary-foreground text-primary hover:bg-primary-foreground/90"
                >
                  Contact Us
                </Button>
                <Button
                  onClick={() => navigate("/")}
                  variant="outline"
                  className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10"
                >
                  View Other Services
                </Button>
              </div>
            </div>
          </section>
        )}
      </main>
      <Footer />
    </div>
  );
}
