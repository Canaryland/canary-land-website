/**
 * Testimonials Section - Organic Modernism Design
 * Social proof with placeholder testimonials and social stats
 */

import { Card } from "@/components/ui/card";
import { Star, Users } from "lucide-react";

const testimonials = [
  {
    name: "Sarah Al-Mansoori",
    role: "Pet Owner",
    content:
      "Amazing service and caring staff! My cat loves the grooming sessions here.",
    rating: 5,
    avatar: "🐱",
  },
  {
    name: "Ahmed Hassan",
    role: "Dog Owner",
    content:
      "My pets love coming here! The boarding facilities are top-notch and very clean.",
    rating: 5,
    avatar: "🐕",
  },
  {
    name: "Fatima Khan",
    role: "Bird Enthusiast",
    content:
      "Best pet shop in Dubai! Found the perfect canary and all the supplies I needed.",
    rating: 5,
    avatar: "🐦",
  },
];

export default function TestimonialsSection() {
  return (
    <section id="testimonials" className="py-24 bg-background diagonal-divider">
      <div className="container">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold text-primary">
            What Our Customers Say
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Join our growing community of happy pet owners
          </p>
        </div>

        {/* Social Stats */}
        <div className="flex justify-center mb-12">
          <div className="inline-flex items-center gap-3 bg-primary/10 px-8 py-4 rounded-full">
            <Users className="w-6 h-6 text-primary" />
            <span className="text-lg font-semibold text-primary">
              Join our community of 36+ pet lovers on Facebook
            </span>
          </div>
        </div>

        {/* Testimonial Cards */}
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card
              key={index}
              className="p-8 space-y-6 border-2 border-border hover:border-primary transition-all duration-300 hover:shadow-xl hover:-translate-y-2 bg-card"
              style={{
                transform: `rotate(${
                  index === 0 ? "-1deg" : index === 1 ? "0deg" : "1deg"
                })`,
              }}
            >
              {/* Stars */}
              <div className="flex gap-1">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-5 h-5 fill-accent text-accent"
                  />
                ))}
              </div>

              {/* Content */}
              <p className="text-card-foreground leading-relaxed text-lg italic">
                "{testimonial.content}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4 pt-4 border-t border-border">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-2xl">
                  {testimonial.avatar}
                </div>
                <div>
                  <p className="font-bold text-card-foreground">
                    {testimonial.name}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {testimonial.role}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
