/**
 * Footer Component - Organic Modernism Design
 * Site footer with branding and links
 */

import { Instagram, Youtube, Globe, MapPin } from "lucide-react";

export default function Footer() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container py-16">
        <div className="grid md:grid-cols-3 gap-12">
          {/* Brand */}
          <div className="space-y-4">
            <img 
              src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663347663075/DvRUIbbgNrmNMbUl.png" 
              alt="Canary Land Pets Logo" 
              className="h-20 w-auto brightness-0 invert"
            />
            <p className="text-primary-foreground/90 leading-relaxed">
              Your paradise for happy, healthy pets! We offer pet supplies,
              nutritious food & adorable companions.
            </p>
            <div></div>
            <div className="flex items-start gap-2 text-sm text-primary-foreground/80">
              <MapPin className="w-4 h-4 mt-1 flex-shrink-0" />
              <span>Dubai, UAE</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="text-xl font-bold">Quick Links</h4>
            <div className="flex flex-col gap-3">
              <button
                onClick={() => scrollToSection("services")}
                className="text-left text-primary-foreground/80 hover:text-primary-foreground transition-colors"
              >
                Services
              </button>
              <button
                onClick={() => scrollToSection("testimonials")}
                className="text-left text-primary-foreground/80 hover:text-primary-foreground transition-colors"
              >
                Testimonials
              </button>
              <button
                onClick={() => scrollToSection("contact")}
                className="text-left text-primary-foreground/80 hover:text-primary-foreground transition-colors"
              >
                Contact
              </button>
            </div>
          </div>

          {/* Social Media */}
          <div className="space-y-4">
            <h4 className="text-xl font-bold">Follow Us</h4>
            <div className="flex flex-col gap-3">
              <a
                href="https://www.instagram.com/canaryland2025"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-primary-foreground/80 hover:text-primary-foreground transition-colors"
              >
                <Instagram className="w-5 h-5" />
                <span>@canaryland2025</span>
              </a>
              <a
                href="https://www.youtube.com/@hameedozootube"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-primary-foreground/80 hover:text-primary-foreground transition-colors"
              >
                <Youtube className="w-5 h-5" />
                <span>hameedozootube</span>
              </a>
              <a
                href="https://canary.land"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-primary-foreground/80 hover:text-primary-foreground transition-colors"
              >
                <Globe className="w-5 h-5" />
                <span>canary.land</span>
              </a>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-12 pt-8 border-t border-primary-foreground/20 text-center text-primary-foreground/70">
          <p>© 2026 Canary Land Pet Shop. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
