/**
 * Google Reviews Carousel Component
 * Design: Organic Modernism - animated floating reviews from left to right
 * Features: Auto-scrolling carousel, star ratings, customer names, smooth animations
 */

import { useEffect, useState } from "react";
import { Star } from "lucide-react";

interface GoogleReview {
  id: string;
  name: string;
  rating: number;
  text: string;
  date: string;
}

// Actual Google reviews from Canary Land Pet Shop
const defaultReviews: GoogleReview[] = [
  {
    id: "1",
    name: "Merwin Fernandes",
    rating: 5,
    text: "Lovely place its ' Old Mc Donald had a farm ei ei eio '",
    date: "Jul 17, 2019",
  },
  {
    id: "2",
    name: "Catherine Amodia",
    rating: 5,
    text: "Many bad comments I read about this shop but in my own experience its not true. This shop is providing many good services.",
    date: "Jun 4, 2023",
  },
  {
    id: "3",
    name: "Dharshini Alexander",
    rating: 5,
    text: "I went to this shop it's quite amazing so many collections of birds and fish. The customer care is so good.",
    date: "May 18, 2024",
  },
  {
    id: "4",
    name: "Mohammed Irfan Shaikh",
    rating: 5,
    text: "Very nice, many varieties of birds, cats and fishes. Different types of foodstuff and accessories also available.",
    date: "Nov 16, 2021",
  },
  {
    id: "5",
    name: "Reswin 47",
    rating: 5,
    text: "I'm a frequent customer to this shop, its really good and well maintained, we could explore variety of birds, fishes and more.",
    date: "Jun 22, 2023",
  },
  {
    id: "6",
    name: "La Lala",
    rating: 5,
    text: "I visited the shop the staff are very friendly. The place is clean and good. I read the reviews online, it's not true way different.",
    date: "May 24, 2023",
  },
  {
    id: "7",
    name: "Farooq Nawaz",
    rating: 5,
    text: "Nice place with budgies, finches, tamed african grey and ring neck. A good variety of fish and aquarium are also there.",
    date: "Mar 31, 2019",
  },
  {
    id: "8",
    name: "Joana Lucas",
    rating: 5,
    text: "They are very experienced with all animals. I trust 100% my pets in this store.",
    date: "Jun 23, 2019",
  },
  {
    id: "9",
    name: "Abdullah Muhammad",
    rating: 5,
    text: "Best pet shop in Dubai. Great service and excellent variety of animals.",
    date: "23 weeks ago",
  },
  {
    id: "10",
    name: "Irfan Jafri",
    rating: 5,
    text: "Good mix variety and one stop shop for the accessories for canary!",
    date: "Nov 22, 2018",
  },
];

export default function GoogleReviewsCarousel() {
  const [reviews] = useState<GoogleReview[]>(defaultReviews);
  const [position, setPosition] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setPosition((prev) => (prev + 1) % (reviews.length * 400));
    }, 50);
    return () => clearInterval(interval);
  }, [reviews.length]);

  const renderStars = (rating: number) => {
    return (
      <div className="flex gap-1">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            size={16}
            className={
              i < rating
                ? "fill-yellow-400 text-yellow-400"
                : "text-gray-300"
            }
          />
        ))}
      </div>
    );
  };

  return (
    <section className="relative py-16 bg-gradient-to-b from-white to-amber-50 overflow-hidden">
      <div className="container mx-auto px-4 mb-12">
        <div className="text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-green-800 mb-2 font-display">
            What Our Customers Say
          </h2>
          <p className="text-gray-600 text-lg">
            Trusted by pet owners across Dubai
          </p>
        </div>
      </div>

      {/* Carousel Container */}
      <div className="relative h-80 overflow-hidden">
        {/* Gradient overlays for smooth fade effect */}
        <div className="absolute left-0 top-0 w-32 h-full bg-gradient-to-r from-white to-transparent z-10 pointer-events-none" />
        <div className="absolute right-0 top-0 w-32 h-full bg-gradient-to-l from-white to-transparent z-10 pointer-events-none" />

        {/* Animated carousel track */}
        <div
          className="flex gap-6 h-full items-center"
          style={{
            transform: `translateX(calc(-${position}px))`,
            transition: "transform 0.05s linear",
          }}
        >
          {/* Duplicate reviews for seamless loop */}
          {[...reviews, ...reviews].map((review, index) => (
            <div
              key={`${review.id}-${index}`}
              className="flex-shrink-0 w-96 bg-white rounded-2xl shadow-lg p-8 border-2 border-green-100 hover:shadow-xl transition-shadow duration-300"
            >
              {/* Star Rating */}
              <div className="mb-4">{renderStars(review.rating)}</div>

              {/* Review Text */}
              <p className="text-gray-700 mb-6 text-base leading-relaxed italic">
                "{review.text}"
              </p>

              {/* Customer Info */}
              <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                <div>
                  <p className="font-semibold text-gray-900">{review.name}</p>
                  <p className="text-sm text-gray-500">{review.date}</p>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center text-white font-bold">
                    {review.name.charAt(0)}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>



      {/* Decorative elements */}
      <div className="absolute top-0 left-10 w-32 h-32 bg-green-100 rounded-full opacity-20 blur-3xl" />
      <div className="absolute bottom-0 right-10 w-40 h-40 bg-yellow-100 rounded-full opacity-20 blur-3xl" />
    </section>
  );
}
