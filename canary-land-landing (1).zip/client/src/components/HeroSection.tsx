/**
 * Hero Section - Organic Modernism Design
 * Diagonal layout with organic blob-shaped image container
 * Background: Custom generated gradient with natural textures
 */

import { Button } from "@/components/ui/button";
import { MapPin } from "lucide-react";

export default function HeroSection() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section
      className="relative min-h-screen flex items-center overflow-hidden pt-20"
      style={{
        backgroundImage: `url('https://private-us-east-1.manuscdn.com/sessionFile/qTkRH805vxXtWV3kFm7uhM/sandbox/KuqxptX1C71NrJGq8l4CrZ-img-1_1770821366000_na1fn_aGVyby1iYWNrZ3JvdW5k.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvcVRrUkg4MDV2eFh0V1Yza0ZtN3VoTS9zYW5kYm94L0t1cXhwdFgxQzcxTnJKR3E4bDRDclotaW1nLTFfMTc3MDgyMTM2NjAwMF9uYTFmbl9hR1Z5YnkxaVlXTnJaM0p2ZFc1ay5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=hyxVR~P5HddJqB~pLBbBTU7cvDIzmUYSetkdWvdxH0UP8Re8ZFkypSZeLrCod6S84sxjmfpkFNzeMu9lWpV7SjuaxVQ91lnIys5HF4YtjVEYOx4~tbyGNN80B948Qtz0GqfZJpVHOlhHhOVCBFeDMHBYopZjeieokbI~8OFPUnwpTwPLsB6~30AqpMxF7alWVMQT46KrZDjhA4M6VK43inae0gG2QY~fKk-yTviu8ryNqyyswzN9k~BSkESIfQj2Ei5~kQdRWms-sl-S3OSE8AYB96IQpx8nsjy3W8X7~PXd2T5Or0i1Kd74KKjZ-iuvZAC87CV1B7PzEliirYVqMA__')`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="container">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8 animate-fade-in-up">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium">
              <MapPin className="w-4 h-4" />
              Dubai, UAE
            </div>

            <h1 className="text-5xl md:text-7xl font-bold text-primary leading-tight">
              Your Paradise for Happy, Healthy Pets!
            </h1>

            <p className="text-xl md:text-2xl text-foreground/80 leading-relaxed">
              We offer pet supplies, nutritious food & adorable companions.
              Experience the finest pet care in Dubai.
            </p>

            <div className="flex flex-wrap gap-4">
              <Button
                size="lg"
                onClick={() => scrollToSection("services")}
                className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-8 text-lg transition-all hover:scale-105 hover:shadow-xl"
              >
                Explore Services
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => scrollToSection("contact")}
                className="rounded-full px-8 text-lg border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-all hover:scale-105"
              >
                Contact Us
              </Button>
            </div>
          </div>

          {/* Right Image - Organic Blob Shape */}
          <div className="relative animate-fade-in-right hidden lg:block">
            <div
              className="organic-blob overflow-hidden shadow-2xl"
              style={{
                width: "100%",
                aspectRatio: "1/1",
              }}
            >
              <img
                src="https://private-us-east-1.manuscdn.com/sessionFile/qTkRH805vxXtWV3kFm7uhM/sandbox/KuqxptX1C71NrJGq8l4CrZ-img-2_1770821366000_na1fn_aGFwcHktcGV0cy1mYW1pbHk.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvcVRrUkg4MDV2eFh0V1Yza0ZtN3VoTS9zYW5kYm94L0t1cXhwdFgxQzcxTnJKR3E4bDRDclotaW1nLTJfMTc3MDgyMTM2NjAwMF9uYTFmbl9hR0Z3Y0hrdGNHVjBjeTFtWVcxcGJIay5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=J1lAeZwiXNuHb23ARYlL5nPygvW-87XXGRMhY0RUWZLADhAlD5gW6sJWApRdh8Q0z-NQYU6l3bxUAm-4gl6CCT6RJrycK~dRNl31dt0loCVa-y2-K2iYmVzpiYxIVQps4pZh1Xr2PQ7h61qsiyh0IAvKO8PgoFXf-Ji9Kq1R6zzfZ4H8tCm07daILvJQPTqn~QRLFskK5tNQur3P9ZTXvwhoTWnCcPO57D8H1rRlPhe~fHjz2lX0vB4XqNQ6wQXPpkMooP7WfNIyZDtn3vf0vpNzo6qZssXffAXFaLYogkdNOZ-1JPPj-qh0WD00sbO5chOn-mVGu8tD6vnxjlFXUw__"
                alt="Happy pets family"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
