/**
 * Grooming Booking Form Component
 * Allows customers to book grooming services with automatic slip generation
 * and WhatsApp notification
 */

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { AlertCircle, CheckCircle, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface GroomingBookingFormProps {
  service?: string;
}

export default function GroomingBookingForm({ service }: GroomingBookingFormProps) {
  const [formData, setFormData] = useState({
    customerName: "",
    customerPhone: "",
    customerEmail: "",
    petName: "",
    petType: "Dog",
    petBreed: "",
    petSize: "Medium",
    service: service || "Full Grooming",
    appointmentDate: "",
    appointmentTime: "10:00",
    groomer: "",
    specialNotes: "",
  });

  const [submitted, setSubmitted] = useState(false);
  const [slipNumber, setSlipNumber] = useState<string | null>(null);

  const createBooking = trpc.grooming.createBooking.useMutation({
    onSuccess: (data) => {
      setSlipNumber(data.slipNumber);
      setSubmitted(true);
      toast.success("Booking confirmed! Slip sent to WhatsApp.");
      
      // Reset form after 3 seconds
      setTimeout(() => {
        setFormData({
          customerName: "",
          customerPhone: "",
          customerEmail: "",
          petName: "",
          petType: "Dog",
          petBreed: "",
          petSize: "Medium",
          service: service || "Full Grooming",
          appointmentDate: "",
          appointmentTime: "10:00",
          groomer: "",
          specialNotes: "",
        });
        setSubmitted(false);
        setSlipNumber(null);
      }, 5000);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create booking");
    },
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (!formData.customerName || !formData.customerPhone || !formData.petName || !formData.appointmentDate) {
      toast.error("Please fill in all required fields");
      return;
    }

    // Phone validation (basic)
    if (!/^[\d\s+\-()]+$/.test(formData.customerPhone) || formData.customerPhone.length < 7) {
      toast.error("Please enter a valid phone number");
      return;
    }

    createBooking.mutate(formData);
  };

  if (submitted && slipNumber) {
    return (
      <Card className="p-8 border-2 border-primary/30 bg-primary/5">
        <div className="text-center space-y-4">
          <CheckCircle className="w-16 h-16 text-primary mx-auto" />
          <h3 className="text-2xl font-bold text-primary">Booking Confirmed!</h3>
          <p className="text-muted-foreground text-lg">
            Your appointment slip has been sent to our WhatsApp
          </p>
          <div className="bg-background p-4 rounded-lg border-2 border-primary">
            <p className="text-sm text-muted-foreground mb-2">Your Slip Number:</p>
            <p className="text-3xl font-bold text-primary">{slipNumber}</p>
          </div>
          <p className="text-sm text-muted-foreground">
            Please save this slip number for your records. You will receive a confirmation message shortly.
          </p>
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 text-left">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-yellow-800">
                <p className="font-semibold mb-1">Important Notes:</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>Extra charges apply for heavy matted coat condition</li>
                  <li>We currently do not accept very aggressive pets</li>
                  <li>Please arrive 10 minutes before your appointment time</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-8 border-2 border-border">
      <h3 className="text-2xl font-bold text-primary mb-6">Book Your Grooming Appointment</h3>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Customer Information Section */}
        <div className="space-y-4">
          <h4 className="font-semibold text-primary text-lg">Customer Information</h4>
          
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="customerName" className="text-foreground font-medium">
                Full Name *
              </Label>
              <Input
                id="customerName"
                name="customerName"
                value={formData.customerName}
                onChange={handleInputChange}
                placeholder="Enter your full name"
                required
                className="border-border"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="customerPhone" className="text-foreground font-medium">
                Phone Number *
              </Label>
              <Input
                id="customerPhone"
                name="customerPhone"
                value={formData.customerPhone}
                onChange={handleInputChange}
                placeholder="+971 50 123 4567"
                required
                className="border-border"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="customerEmail" className="text-foreground font-medium">
              Email Address
            </Label>
            <Input
              id="customerEmail"
              name="customerEmail"
              type="email"
              value={formData.customerEmail}
              onChange={handleInputChange}
              placeholder="your@email.com"
              className="border-border"
            />
          </div>
        </div>

        {/* Pet Information Section */}
        <div className="space-y-4">
          <h4 className="font-semibold text-primary text-lg">Pet Information</h4>
          
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="petName" className="text-foreground font-medium">
                Pet Name *
              </Label>
              <Input
                id="petName"
                name="petName"
                value={formData.petName}
                onChange={handleInputChange}
                placeholder="Enter your pet's name"
                required
                className="border-border"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="petType" className="text-foreground font-medium">
                Pet Type *
              </Label>
              <Select value={formData.petType} onValueChange={(value) => handleSelectChange("petType", value)}>
                <SelectTrigger className="border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Dog">Dog</SelectItem>
                  <SelectItem value="Cat">Cat</SelectItem>
                  <SelectItem value="Bird">Bird</SelectItem>
                  <SelectItem value="Rabbit">Rabbit</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="petBreed" className="text-foreground font-medium">
                Breed
              </Label>
              <Input
                id="petBreed"
                name="petBreed"
                value={formData.petBreed}
                onChange={handleInputChange}
                placeholder="e.g., Golden Retriever"
                className="border-border"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="petSize" className="text-foreground font-medium">
                Size *
              </Label>
              <Select value={formData.petSize} onValueChange={(value) => handleSelectChange("petSize", value)}>
                <SelectTrigger className="border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Small">Small</SelectItem>
                  <SelectItem value="Medium">Medium</SelectItem>
                  <SelectItem value="Large">Large</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Appointment Details Section */}
        <div className="space-y-4">
          <h4 className="font-semibold text-primary text-lg">Appointment Details</h4>
          
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="service" className="text-foreground font-medium">
                Service *
              </Label>
              <Select value={formData.service} onValueChange={(value) => handleSelectChange("service", value)}>
                <SelectTrigger className="border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Full Grooming">Full Grooming</SelectItem>
                  <SelectItem value="Basic Grooming">Basic Grooming</SelectItem>
                  <SelectItem value="Express Bath">Express Bath</SelectItem>
                  <SelectItem value="Nail Cut">Nail Cut</SelectItem>
                  <SelectItem value="De-shedding Treatment">De-shedding Treatment</SelectItem>
                  <SelectItem value="Medicated Bath">Medicated Bath</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="appointmentDate" className="text-foreground font-medium">
                Appointment Date *
              </Label>
              <Input
                id="appointmentDate"
                name="appointmentDate"
                type="date"
                value={formData.appointmentDate}
                onChange={handleInputChange}
                required
                className="border-border"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="appointmentTime" className="text-foreground font-medium">
                Appointment Time *
              </Label>
              <Input
                id="appointmentTime"
                name="appointmentTime"
                type="time"
                value={formData.appointmentTime}
                onChange={handleInputChange}
                required
                className="border-border"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="groomer" className="text-foreground font-medium">
                Preferred Groomer
              </Label>
              <Input
                id="groomer"
                name="groomer"
                value={formData.groomer}
                onChange={handleInputChange}
                placeholder="e.g., Ali, Fatima"
                className="border-border"
              />
            </div>
          </div>
        </div>

        {/* Special Notes Section */}
        <div className="space-y-4">
          <h4 className="font-semibold text-primary text-lg">Special Notes</h4>
          
          <div className="space-y-2">
            <Label htmlFor="specialNotes" className="text-foreground font-medium">
              Any special requests or health concerns?
            </Label>
            <Textarea
              id="specialNotes"
              name="specialNotes"
              value={formData.specialNotes}
              onChange={handleInputChange}
              placeholder="e.g., Pet has sensitive skin, prefers gentle handling..."
              className="border-border min-h-24"
            />
          </div>

          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-yellow-800">
                <p className="font-semibold mb-1">Important Notes:</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>Extra charges apply for heavy matted coat condition</li>
                  <li>We currently do not accept very aggressive pets</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <Button
          type="submit"
          disabled={createBooking.isPending}
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-6 text-lg font-semibold"
        >
          {createBooking.isPending ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            "Confirm Booking & Send to WhatsApp"
          )}
        </Button>

        <p className="text-xs text-muted-foreground text-center">
          By confirming, you agree to our appointment terms and conditions
        </p>
      </form>
    </Card>
  );
}
