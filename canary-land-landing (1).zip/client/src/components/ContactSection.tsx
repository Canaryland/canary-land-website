/**
 * Contact Section - Organic Modernism Design
 * Contact form with business information
 */

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  MapPin,
  Mail,
  Clock,
  Instagram,
  Youtube,
  Globe,
} from "lucide-react";
import { toast } from "sonner";

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Form submission logic would go here
    toast.success("Thank you! We'll get back to you soon.", {
      description: "Your message has been received.",
    });
    setFormData({ name: "", email: "", phone: "", message: "" });
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <section id="contact" className="py-24 bg-primary/5 diagonal-divider">
      <div className="container">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold text-primary">
            Get in Touch
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Have questions? We're here to help you and your pets
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Form */}
          <div className="bg-white p-8 rounded-3xl shadow-xl">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-foreground font-medium">
                  Name *
                </Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="rounded-xl border-2 focus:border-primary"
                  placeholder="Your name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-foreground font-medium">
                  Email *
                </Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="rounded-xl border-2 focus:border-primary"
                  placeholder="your@email.com"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone" className="text-foreground font-medium">
                  Phone
                </Label>
                <Input
                  id="phone"
                  name="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={handleChange}
                  className="rounded-xl border-2 focus:border-primary"
                  placeholder="+971 XX XXX XXXX"
                />
              </div>

              <div className="space-y-2">
                <Label
                  htmlFor="message"
                  className="text-foreground font-medium"
                >
                  Message *
                </Label>
                <Textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  className="rounded-xl border-2 focus:border-primary min-h-32"
                  placeholder="Tell us how we can help you and your pet..."
                />
              </div>

              <Button
                type="submit"
                size="lg"
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground rounded-full text-lg transition-all hover:scale-105 hover:shadow-xl"
              >
                Send Message
              </Button>
            </form>
          </div>

          {/* Contact Information */}
          <div className="space-y-8">
            <div className="bg-white p-8 rounded-3xl shadow-xl space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-foreground mb-2">
                    Visit Us
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Shop #22 - Al Nahda St - Al Twar First
                    <br />
                    Al Twar 1, Dubai, United Arab Emirates
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-foreground mb-2">
                    Email Us
                  </h3>
                  <a
                    href="mailto:canaryland2025@gmail.com"
                    className="text-primary hover:underline"
                  >
                    canaryland2025@gmail.com
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Clock className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-foreground mb-2">
                    Business Hours
                  </h3>
                  <p className="text-muted-foreground">
                    Open now
                    <br />
                    <span className="text-sm">
                      Visit us during business hours
                    </span>
                  </p>
                </div>
              </div>
            </div>

            {/* Social Media Links */}
            <div className="bg-white p-8 rounded-3xl shadow-xl">
              <h3 className="font-bold text-xl text-foreground mb-6">
                Connect With Us
              </h3>
              <div className="flex flex-wrap gap-4">
                <a
                  href="https://www.instagram.com/canaryland2025"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 px-6 py-3 bg-primary/10 hover:bg-primary text-primary hover:text-primary-foreground rounded-full transition-all hover:scale-105"
                >
                  <Instagram className="w-5 h-5" />
                  <span className="font-medium">Instagram</span>
                </a>
                <a
                  href="https://www.youtube.com/@hameedozootube"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 px-6 py-3 bg-primary/10 hover:bg-primary text-primary hover:text-primary-foreground rounded-full transition-all hover:scale-105"
                >
                  <Youtube className="w-5 h-5" />
                  <span className="font-medium">YouTube</span>
                </a>
                <a
                  href="https://canary.land"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 px-6 py-3 bg-primary/10 hover:bg-primary text-primary hover:text-primary-foreground rounded-full transition-all hover:scale-105"
                >
                  <Globe className="w-5 h-5" />
                  <span className="font-medium">Website</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
