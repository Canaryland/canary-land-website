/**
 * Services Section - Organic Modernism Design
 * Service cards in offset grid layout with organic shapes
 */

import { Card } from "@/components/ui/card";
import { Scissors, Home, Bird, Fish, ShoppingBag } from "lucide-react";
import { useLocation } from "wouter";

const services = [
  {
    id: "pet-grooming",
    icon: Scissors,
    title: "Pet Grooming",
    description:
      "Professional grooming services to keep your pets looking and feeling their best",
    image:
      "https://private-us-east-1.manuscdn.com/sessionFile/qTkRH805vxXtWV3kFm7uhM/sandbox/KuqxptX1C71NrJGq8l4CrZ-img-3_1770821374000_na1fn_cGV0LWdyb29taW5nLXNlcnZpY2U.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvcVRrUkg4MDV2eFh0V1Yza0ZtN3VoTS9zYW5kYm94L0t1cXhwdFgxQzcxTnJKR3E4bDRDclotaW1nLTNfMTc3MDgyMTM3NDAwMF9uYTFmbl9jR1YwTFdkeWIyOXRhVzVuTFhObGNuWnBZMlUucG5nP3gtb3NzLXByb2Nlc3M9aW1hZ2UvcmVzaXplLHdfMTkyMCxoXzE5MjAvZm9ybWF0LHdlYnAvcXVhbGl0eSxxXzgwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=FYCpLqAMxbb79oi625uttJ6jGLUQB9ofos~8qdb4gwBjgtnPMKKVa59zqjBRgbC0wqBV2ZPPdGhDIWh5KcTEQ8RO1aQytVe2Vmov3Q95-Ncsrh2jNSSExCHLzKKK3Od6QOxRbaBPwlP3-VcNGoSg0b3b-QD4NkYTkGFjXnhWMmqOi5dZkio8hBbs9YIb011iEhNsIcc-VRO~TA~EjO-PGDns5mLN6n6FuP-~cjMRTu8ntXs95W-u5BRHap11XcfreKSF0B5TgZrlS-sR1ajSxLwHumRZWoHrSyKLABEaC7csnqyad5PfhzUdOOjCzQ1AcJP-9UeWeH7XsE8jspgqZA__",
  },
  {
    id: "pet-boarding",
    icon: Home,
    title: "Pet Boarding",
    description:
      "Safe, comfortable boarding facilities for your beloved companions",
    image:
      "https://images.unsplash.com/photo-1548681528-6a5c45b66b42?w=800&auto=format&fit=crop",
  },
  {
    id: "animal-trading",
    icon: Bird,
    title: "Animal Trading",
    description: "Exotic birds and unique pets from trusted sources",
    image:
      "https://private-us-east-1.manuscdn.com/sessionFile/qTkRH805vxXtWV3kFm7uhM/sandbox/KuqxptX1C71NrJGq8l4CrZ-img-5_1770821370000_na1fn_ZXhvdGljLWJpcmRzLWNvbGxlY3Rpb24.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvcVRrUkg4MDV2eFh0V1Yza0ZtN3VoTS9zYW5kYm94L0t1cXhwdFgxQzcxTnJKR3E4bDRDclotaW1nLTVfMTc3MDgyMTM3MDAwMF9uYTFmbl9aWGh2ZEdsakxXSnBjbVJ6TFdOdmJHeGxZM1JwYjI0LnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=qH3YhiEEv8RWHEZDUX5r5xtteZnzjYM59fPybKbnBEjaa0zMFtdhOgSBGegaax5g0mAVV0YWeZyUfcYIyWOFRh~nQrXHhEpXJtM298BP6xYPdqkbT00jwbDozYdynmyONm9DCVhU0v9gpO~xQ~nid6pq1GKO~Oa~fKK2wIZpw90vwzzhoJjxgASxfIPtrnVjoDvI86GWIcz7O36cO-FZYOwGWPQ-lfIJqHiwUltbE9ImnwTxHDEWbfblSBD9RV1om8SCK4qBNEhtUPORMYoVJierqFe3zsNAglG4hpRWcvEI2hyXym913Cw-FOHFVeZahBtkEoq62xSkd43BkknEUA__",
  },
  {
    id: "aquatic-animals",
    icon: Fish,
    title: "Aquatic Animals",
    description: "Complete aquarium solutions and beautiful aquatic life",
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663347663075/sMhGugEsXeNbPPgg.jpg",
  },
  {
    id: "pet-food-supply",
    icon: ShoppingBag,
    title: "Pet Food & Supply",
    description: "Premium pet food and all the supplies your pets need",
    image:
      "https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=800&auto=format&fit=crop",
  },
];

export default function ServicesSection() {
  const [, navigate] = useLocation();

  const handleServiceClick = (serviceId: string) => {
    navigate(`/service/${serviceId}`);
  };

  return (
    <section id="services" className="py-24 bg-background diagonal-divider">
      <div className="container">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold text-primary">
            Our Services
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Comprehensive pet care solutions tailored to your companion's needs
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card
                key={index}
                onClick={() => handleServiceClick(service.id)}
                className="group overflow-hidden border-2 border-border hover:border-primary transition-all duration-300 hover:shadow-2xl hover:-translate-y-2 cursor-pointer bg-card"
                style={{
                  transform: `rotate(${index % 2 === 0 ? "-1deg" : "1deg"})`,
                }}
              >
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-primary/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
                <div className="p-6 space-y-4">
                  <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary group-hover:scale-110 transition-all duration-300">
                    <Icon className="w-7 h-7 text-primary group-hover:text-primary-foreground transition-colors" />
                  </div>
                  <h3 className="text-2xl font-bold text-card-foreground group-hover:text-primary transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {service.description}
                  </p>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
