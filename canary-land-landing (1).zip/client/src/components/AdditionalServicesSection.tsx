/**
 * Additional Services Section - Organic Modernism Design
 * Icon-based list of additional features and services
 */

import { Package, Store, Truck, Sparkles } from "lucide-react";

const additionalServices = [
  {
    icon: Sparkles,
    title: "Teeth Brushing & Nail Cut",
    description: "Professional grooming extras for complete pet care",
  },
  {
    icon: Truck,
    title: "Delivery",
    description: "Convenient home delivery for all your pet supplies",
  },
  {
    icon: Package,
    title: "In-store Pickup",
    description: "Order online and pick up at your convenience",
  },
  {
    icon: Store,
    title: "In-store Shopping",
    description: "Visit our Dubai location for personalized service",
  },
];

export default function AdditionalServicesSection() {
  return (
    <section className="py-20 bg-primary/5">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
            Additional Services
          </h2>
          <p className="text-lg text-muted-foreground">
            More ways we make pet care convenient for you
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {additionalServices.map((service, index) => {
            const Icon = service.icon;
            return (
              <div
                key={index}
                className="flex flex-col items-center text-center space-y-4 p-6 rounded-3xl bg-white hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group"
              >
                <div className="w-16 h-16 rounded-full bg-accent/20 flex items-center justify-center group-hover:bg-accent group-hover:scale-110 transition-all duration-300">
                  <Icon className="w-8 h-8 text-accent-foreground" />
                </div>
                <h3 className="text-xl font-bold text-foreground">
                  {service.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {service.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
