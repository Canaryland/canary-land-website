import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { AlertCircle, CheckCircle2, Loader2 } from "lucide-react";

interface PetBoardingBookingFormProps {
  service?: string;
}

export default function PetBoardingBookingForm({ service }: PetBoardingBookingFormProps = {}) {
  const [formData, setFormData] = useState({
    customerName: "",
    customerPhone: "",
    customerEmail: "",
    petName: "",
    petType: "Dog",
    petBreed: "",
    petSize: "Medium",
    checkInDate: "",
    checkOutDate: "",
    specialNotes: "",
    paymentMethod: "shop" as "online" | "shop",
  });

  const [availabilityStatus, setAvailabilityStatus] = useState<{
    checking: boolean;
    available: boolean | null;
    message: string;
  }>({
    checking: false,
    available: null,
    message: "",
  });

  const [numberOfDays, setNumberOfDays] = useState(0);
  const [totalPrice, setTotalPrice] = useState(0);

  const checkAvailabilityMutation = trpc.boarding.checkAvailability.useQuery(
    {
      checkInDate: formData.checkInDate,
      checkOutDate: formData.checkOutDate,
    },
    {
      enabled: !!(formData.checkInDate && formData.checkOutDate),
      refetchOnWindowFocus: false,
    }
  );

  const createBookingMutation = trpc.boarding.createBooking.useMutation();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setFormData((prev) => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleDateChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));

    // Calculate number of days and total price
    if (field === "checkInDate" || field === "checkOutDate") {
      const checkIn = field === "checkInDate" ? new Date(value) : new Date(formData.checkInDate);
      const checkOut = field === "checkOutDate" ? new Date(value) : new Date(formData.checkOutDate);

      if (checkIn && checkOut && checkOut > checkIn) {
        const days = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24));
        const price = days * 50; // AED 50 per day
        setNumberOfDays(days);
        setTotalPrice(price);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (!formData.customerName || !formData.customerPhone || !formData.petName) {
      toast.error("Please fill in all required fields");
      return;
    }

    if (!formData.checkInDate || !formData.checkOutDate) {
      toast.error("Please select check-in and check-out dates");
      return;
    }

    if (new Date(formData.checkOutDate) <= new Date(formData.checkInDate)) {
      toast.error("Check-out date must be after check-in date");
      return;
    }

    // Check availability before submitting
    if (!checkAvailabilityMutation.data?.available) {
      toast.error("Selected dates are not available. Please choose different dates.");
      return;
    }

    try {
      const result = await createBookingMutation.mutateAsync({
        customerName: formData.customerName,
        customerPhone: formData.customerPhone,
        customerEmail: formData.customerEmail,
        petName: formData.petName,
        petType: formData.petType,
        petBreed: formData.petBreed,
        petSize: formData.petSize,
        checkInDate: formData.checkInDate,
        checkOutDate: formData.checkOutDate,
        specialNotes: formData.specialNotes,
        paymentMethod: formData.paymentMethod,
      });

      toast.success(`Booking confirmed! Slip #${result.slipNumber}`);
      
      // Reset form
      setFormData({
        customerName: "",
        customerPhone: "",
        customerEmail: "",
        petName: "",
        petType: "Dog",
        petBreed: "",
        petSize: "Medium",
        checkInDate: "",
        checkOutDate: "",
        specialNotes: "",
        paymentMethod: "shop",
      });
      setNumberOfDays(0);
      setTotalPrice(0);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to create booking");
    }
  };

  // Update availability status based on query
  useEffect(() => {
    if (formData.checkInDate && formData.checkOutDate) {
      if (checkAvailabilityMutation.isLoading) {
        setAvailabilityStatus({
          checking: true,
          available: null,
          message: "Checking availability...",
        });
      } else if (checkAvailabilityMutation.data) {
        setAvailabilityStatus({
          checking: false,
          available: checkAvailabilityMutation.data.available,
          message: checkAvailabilityMutation.data.available
            ? "✓ Dates are available!"
            : "✗ These dates are already booked",
        });
      }
    }
  }, [checkAvailabilityMutation.data, checkAvailabilityMutation.isLoading, formData.checkInDate, formData.checkOutDate]);

  return (
    <div className="bg-white rounded-lg p-8 shadow-lg max-w-2xl mx-auto">
      <h2 className="text-3xl font-bold text-green-800 mb-2">🏠 Pet Boarding</h2>
      <p className="text-gray-600 mb-6">Book a comfortable stay for your beloved pet</p>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Customer Information */}
        <div className="border-b pb-6">
          <h3 className="text-xl font-semibold text-green-700 mb-4">Customer Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="customerName">Full Name *</Label>
              <Input
                id="customerName"
                type="text"
                placeholder="Enter your full name"
                value={formData.customerName}
                onChange={handleInputChange}
                required
              />
            </div>
            <div>
              <Label htmlFor="customerPhone">Phone Number *</Label>
              <Input
                id="customerPhone"
                type="tel"
                placeholder="+971 50 123 4567"
                value={formData.customerPhone}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="md:col-span-2">
              <Label htmlFor="customerEmail">Email Address</Label>
              <Input
                id="customerEmail"
                type="email"
                placeholder="your@email.com"
                value={formData.customerEmail}
                onChange={handleInputChange}
              />
            </div>
          </div>
        </div>

        {/* Pet Information */}
        <div className="border-b pb-6">
          <h3 className="text-xl font-semibold text-green-700 mb-4">Pet Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="petName">Pet Name *</Label>
              <Input
                id="petName"
                type="text"
                placeholder="Enter your pet's name"
                value={formData.petName}
                onChange={handleInputChange}
                required
              />
            </div>
            <div>
              <Label htmlFor="petType">Pet Type *</Label>
              <Select value={formData.petType} onValueChange={(value) => handleSelectChange("petType", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Dog">Dog</SelectItem>
                  <SelectItem value="Cat">Cat</SelectItem>
                  <SelectItem value="Bird">Bird</SelectItem>
                  <SelectItem value="Rabbit">Rabbit</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="petBreed">Breed</Label>
              <Input
                id="petBreed"
                type="text"
                placeholder="e.g., Golden Retriever"
                value={formData.petBreed}
                onChange={handleInputChange}
              />
            </div>
            <div>
              <Label htmlFor="petSize">Size *</Label>
              <Select value={formData.petSize} onValueChange={(value) => handleSelectChange("petSize", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Small">Small</SelectItem>
                  <SelectItem value="Medium">Medium</SelectItem>
                  <SelectItem value="Large">Large</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Booking Dates */}
        <div className="border-b pb-6">
          <h3 className="text-xl font-semibold text-green-700 mb-4">Booking Dates</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="checkInDate">Check-In Date *</Label>
              <Input
                id="checkInDate"
                type="date"
                value={formData.checkInDate}
                onChange={(e) => handleDateChange("checkInDate", e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="checkOutDate">Check-Out Date *</Label>
              <Input
                id="checkOutDate"
                type="date"
                value={formData.checkOutDate}
                onChange={(e) => handleDateChange("checkOutDate", e.target.value)}
                required
              />
            </div>
          </div>

          {/* Availability Status */}
          {formData.checkInDate && formData.checkOutDate && (
            <div className={`mt-4 p-4 rounded-lg flex items-center gap-3 ${
              availabilityStatus.available
                ? "bg-green-50 border border-green-200"
                : availabilityStatus.available === false
                ? "bg-red-50 border border-red-200"
                : "bg-blue-50 border border-blue-200"
            }`}>
              {availabilityStatus.checking ? (
                <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
              ) : availabilityStatus.available ? (
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-600" />
              )}
              <span className={
                availabilityStatus.available
                  ? "text-green-700"
                  : availabilityStatus.available === false
                  ? "text-red-700"
                  : "text-blue-700"
              }>
                {availabilityStatus.message}
              </span>
            </div>
          )}

          {/* Pricing Summary */}
          {numberOfDays > 0 && (
            <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Number of Days:</span>
                <span className="font-semibold text-gray-900">{numberOfDays} days</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Price Per Day:</span>
                <span className="font-semibold text-gray-900">AED 50</span>
              </div>
              <div className="border-t border-green-200 pt-2 flex justify-between">
                <span className="text-lg font-bold text-green-700">Total Price:</span>
                <span className="text-lg font-bold text-green-700">AED {totalPrice}</span>
              </div>
            </div>
          )}
        </div>

        {/* Special Notes */}
        <div className="border-b pb-6">
          <h3 className="text-xl font-semibold text-green-700 mb-4">Special Notes</h3>
          <Label htmlFor="specialNotes">Any special requests or health concerns?</Label>
          <Textarea
            id="specialNotes"
            placeholder="e.g., Pet has allergies, requires medication, prefers certain food..."
            value={formData.specialNotes}
            onChange={handleInputChange}
            className="mt-2"
          />
        </div>

        {/* Payment Method */}
        <div className="border-b pb-6">
          <h3 className="text-xl font-semibold text-green-700 mb-4">Payment Method</h3>
          <div className="space-y-3">
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="radio"
                name="paymentMethod"
                value="shop"
                checked={formData.paymentMethod === "shop"}
                onChange={(e) => handleSelectChange("paymentMethod", e.target.value)}
                className="w-4 h-4"
              />
              <span className="text-gray-700">Pay at Shop (On Check-In)</span>
            </label>
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="radio"
                name="paymentMethod"
                value="online"
                checked={formData.paymentMethod === "online"}
                onChange={(e) => handleSelectChange("paymentMethod", e.target.value)}
                className="w-4 h-4"
              />
              <span className="text-gray-700">Pay Online (Stripe)</span>
            </label>
          </div>
        </div>

        {/* Important Notes */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <h4 className="font-semibold text-yellow-800 mb-2">⚠️ Important Notes:</h4>
          <ul className="text-sm text-yellow-700 space-y-1">
            <li>• Please provide all necessary pet care instructions</li>
            <li>• Ensure vaccinations are up to date</li>
            <li>• Bring any required medications or special food</li>
            <li>• We provide comfortable accommodation and daily care</li>
          </ul>
        </div>

        {/* Submit Button */}
        <Button
          type="submit"
          disabled={createBookingMutation.isPending || !checkAvailabilityMutation.data?.available}
          className="w-full bg-green-700 hover:bg-green-800 text-white font-semibold py-3 rounded-lg"
        >
          {createBookingMutation.isPending ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            "Confirm Booking & Send to WhatsApp"
          )}
        </Button>

        <p className="text-xs text-gray-500 text-center">
          By confirming, you agree to our booking terms and conditions
        </p>
      </form>
    </div>
  );
}
