import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, datetime, tinyint } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Grooming Booking Table
export const groomingBookings = mysqlTable("grooming_bookings", {
  id: int("id").autoincrement().primaryKey(),
  slipNumber: varchar("slip_number", { length: 32 }).notNull().unique(),
  customerName: varchar("customer_name", { length: 255 }).notNull(),
  customerPhone: varchar("customer_phone", { length: 20 }).notNull(),
  customerEmail: varchar("customer_email", { length: 320 }),
  petName: varchar("pet_name", { length: 255 }).notNull(),
  petType: varchar("pet_type", { length: 100 }).notNull(),
  petBreed: varchar("pet_breed", { length: 255 }),
  petSize: varchar("pet_size", { length: 50 }).notNull(),
  service: varchar("service", { length: 255 }).notNull(),
  appointmentDate: datetime("appointment_date").notNull(),
  appointmentTime: varchar("appointment_time", { length: 10 }).notNull(),
  groomer: varchar("groomer", { length: 255 }),
  specialNotes: text("special_notes"),
  status: mysqlEnum("status", ["Scheduled", "Confirmed", "Completed", "Cancelled"]).default("Scheduled").notNull(),
  whatsappSent: timestamp("whatsapp_sent"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type GroomingBooking = typeof groomingBookings.$inferSelect;
export type InsertGroomingBooking = typeof groomingBookings.$inferInsert;

// Pet Boarding Table
export const petBoardingBookings = mysqlTable("pet_boarding_bookings", {
  id: int("id").autoincrement().primaryKey(),
  slipNumber: varchar("slip_number", { length: 32 }).notNull().unique(),
  customerName: varchar("customer_name", { length: 255 }).notNull(),
  customerPhone: varchar("customer_phone", { length: 20 }).notNull(),
  customerEmail: varchar("customer_email", { length: 320 }),
  petName: varchar("pet_name", { length: 255 }).notNull(),
  petType: varchar("pet_type", { length: 100 }).notNull(),
  petBreed: varchar("pet_breed", { length: 255 }),
  petSize: varchar("pet_size", { length: 50 }).notNull(),
  checkInDate: datetime("check_in_date").notNull(),
  checkOutDate: datetime("check_out_date").notNull(),
  numberOfDays: int("number_of_days").notNull(),
  pricePerDay: int("price_per_day").notNull(),
  totalPrice: int("total_price").notNull(),
  specialNotes: text("special_notes"),
  status: mysqlEnum("status", ["Pending", "Confirmed", "CheckedIn", "CheckedOut", "Cancelled"]).default("Pending").notNull(),
  whatsappSent: timestamp("whatsapp_sent"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type PetBoardingBooking = typeof petBoardingBookings.$inferSelect;
export type InsertPetBoardingBooking = typeof petBoardingBookings.$inferInsert;

// Payment Tracking Table
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  stripePaymentIntentId: varchar("stripe_payment_intent_id", { length: 255 }).unique(),
  bookingType: mysqlEnum("booking_type", ["grooming", "boarding"]).notNull(),
  bookingId: int("booking_id").notNull(),
  amount: int("amount").notNull(),
  currency: varchar("currency", { length: 3 }).default("AED").notNull(),
  status: mysqlEnum("status", ["pending", "completed", "failed", "refunded"]).default("pending").notNull(),
  paymentMethod: varchar("payment_method", { length: 50 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

// Email Notifications Table
export const emailNotifications = mysqlTable("email_notifications", {
  id: int("id").autoincrement().primaryKey(),
  bookingType: mysqlEnum("booking_type", ["grooming", "boarding"]).notNull(),
  bookingId: int("booking_id").notNull(),
  customerEmail: varchar("customer_email", { length: 320 }).notNull(),
  customerName: varchar("customer_name", { length: 255 }).notNull(),
  notificationType: mysqlEnum("notification_type", ["confirmation", "reminder", "update", "cancellation"]).notNull(),
  subject: varchar("subject", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["pending", "sent", "failed"]).default("pending").notNull(),
  sentAt: timestamp("sent_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type EmailNotification = typeof emailNotifications.$inferSelect;
export type InsertEmailNotification = typeof emailNotifications.$inferInsert;

// Customers Table
export const customers = mysqlTable("customers", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  phone: varchar("phone", { length: 20 }).notNull(),
  address: text("address"),
  totalBookings: int("total_bookings").default(0).notNull(),
  totalSpent: int("total_spent").default(0).notNull(),
  lastBookingDate: datetime("last_booking_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = typeof customers.$inferInsert;

// Customer Pets Table
export const customerPets = mysqlTable("customer_pets", {
  id: int("id").autoincrement().primaryKey(),
  customerId: int("customer_id").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  type: varchar("type", { length: 100 }).notNull(),
  breed: varchar("breed", { length: 255 }),
  size: varchar("size", { length: 50 }),
  dateOfBirth: datetime("date_of_birth"),
  specialNotes: text("special_notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type CustomerPet = typeof customerPets.$inferSelect;
export type InsertCustomerPet = typeof customerPets.$inferInsert;

// Loyalty Points Table
export const loyaltyPoints = mysqlTable("loyalty_points", {
  id: int("id").autoincrement().primaryKey(),
  customerId: int("customer_id").notNull(),
  currentBalance: int("current_balance").default(0).notNull(),
  totalEarned: int("total_earned").default(0).notNull(),
  totalRedeemed: int("total_redeemed").default(0).notNull(),
  lastEarnedDate: datetime("last_earned_date"),
  lastRedeemedDate: datetime("last_redeemed_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type LoyaltyPoints = typeof loyaltyPoints.$inferSelect;
export type InsertLoyaltyPoints = typeof loyaltyPoints.$inferInsert;

// Points Transaction History Table
export const pointsTransactions = mysqlTable("points_transactions", {
  id: int("id").autoincrement().primaryKey(),
  customerId: int("customer_id").notNull(),
  transactionType: mysqlEnum("transaction_type", ["earned", "redeemed", "adjusted", "expired"]).notNull(),
  points: int("points").notNull(),
  reason: varchar("reason", { length: 255 }).notNull(),
  bookingType: varchar("booking_type", { length: 50 }),
  bookingId: int("booking_id"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type PointsTransaction = typeof pointsTransactions.$inferSelect;
export type InsertPointsTransaction = typeof pointsTransactions.$inferInsert;

// Points Redemption Options Table
export const redemptionOptions = mysqlTable("redemption_options", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  pointsRequired: int("points_required").notNull(),
  discountAmount: int("discount_amount"),
  discountPercentage: int("discount_percentage"),
  applicableServices: varchar("applicable_services", { length: 500 }),
  isActive: int("is_active").notNull().default(1),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type RedemptionOption = typeof redemptionOptions.$inferSelect;
export type InsertRedemptionOption = typeof redemptionOptions.$inferInsert;
