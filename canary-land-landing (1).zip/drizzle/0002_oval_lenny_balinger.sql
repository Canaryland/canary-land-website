CREATE TABLE `payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`stripe_payment_intent_id` varchar(255),
	`booking_type` enum('grooming','boarding') NOT NULL,
	`booking_id` int NOT NULL,
	`amount` int NOT NULL,
	`currency` varchar(3) NOT NULL DEFAULT 'AED',
	`status` enum('pending','completed','failed','refunded') NOT NULL DEFAULT 'pending',
	`payment_method` varchar(50),
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `payments_id` PRIMARY KEY(`id`),
	CONSTRAINT `payments_stripe_payment_intent_id_unique` UNIQUE(`stripe_payment_intent_id`)
);
--> statement-breakpoint
CREATE TABLE `pet_boarding_bookings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slip_number` varchar(32) NOT NULL,
	`customer_name` varchar(255) NOT NULL,
	`customer_phone` varchar(20) NOT NULL,
	`customer_email` varchar(320),
	`pet_name` varchar(255) NOT NULL,
	`pet_type` varchar(100) NOT NULL,
	`pet_breed` varchar(255),
	`pet_size` varchar(50) NOT NULL,
	`check_in_date` datetime NOT NULL,
	`check_out_date` datetime NOT NULL,
	`number_of_days` int NOT NULL,
	`price_per_day` int NOT NULL,
	`total_price` int NOT NULL,
	`special_notes` text,
	`status` enum('Pending','Confirmed','CheckedIn','CheckedOut','Cancelled') NOT NULL DEFAULT 'Pending',
	`whatsapp_sent` timestamp,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `pet_boarding_bookings_id` PRIMARY KEY(`id`),
	CONSTRAINT `pet_boarding_bookings_slip_number_unique` UNIQUE(`slip_number`)
);
