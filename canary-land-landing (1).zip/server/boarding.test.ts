import { describe, expect, it } from "vitest";

// Helper to calculate days between dates
function calculateDays(checkInDate: string, checkOutDate: string): number {
  const checkIn = new Date(checkInDate);
  const checkOut = new Date(checkOutDate);
  const timeDiff = checkOut.getTime() - checkIn.getTime();
  return Math.ceil(timeDiff / (1000 * 3600 * 24));
}

// Helper to calculate boarding price
function calculateBoardingPrice(days: number, pricePerDay: number = 50): string {
  return (days * pricePerDay).toFixed(2);
}

describe("pet boarding logic", () => {
  it("calculates correct number of days", () => {
    const days1 = calculateDays("2026-03-01", "2026-03-04");
    const days2 = calculateDays("2026-03-01", "2026-03-08");

    expect(days1).toBe(3);
    expect(days2).toBe(7);
  });

  it("calculates correct pricing", () => {
    const price1 = calculateBoardingPrice(3);
    const price2 = calculateBoardingPrice(7);
    const price5 = calculateBoardingPrice(5);

    expect(price1).toBe("150.00");
    expect(price2).toBe("350.00");
    expect(price5).toBe("250.00");
  });

  it("validates date format", () => {
    const checkInDate = "2026-03-01";
    const checkOutDate = "2026-03-04";
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;

    expect(checkInDate).toMatch(dateRegex);
    expect(checkOutDate).toMatch(dateRegex);
  });

  it("formats booking slip correctly", () => {
    const slip = `
🐾 CANARY LAND PET BOARDING 🐾
Premium Pet Boarding Services

📋 BOOKING CONFIRMATION SLIP

Slip No: CL-20260212-001
Print Date: 12/02/2026 10:00:00 AM

⚡ STATUS: PENDING

BOOKING DETAILS
Check-In Date: 2026-03-01
Check-Out Date: 2026-03-04
Number of Days: 3
Status: Pending Confirmation

CUSTOMER INFORMATION
Customer Name: John Doe
Phone: +971501234567
Email: john@example.com

PET INFORMATION
Pet Name: Buddy
Pet Type: Dog
Breed: Labrador
Size: Large

PRICING DETAILS
Price Per Day: AED 50
Number of Days: 3
Total Price: AED 150.00

SPECIAL NOTES
None

⚠️ IMPORTANT NOTES:
- Please provide all necessary pet care instructions
- Ensure vaccinations are up to date
- Bring any required medications or special food
- We provide comfortable accommodation and daily care

💳 PAYMENT: At Shop
Payment due on check-in.

Thank you for choosing Canary Land Pets! 🐾
    `;

    expect(slip).toContain("CANARY LAND PET BOARDING");
    expect(slip).toContain("John Doe");
    expect(slip).toContain("Buddy");
    expect(slip).toContain("Labrador");
    expect(slip).toContain("Check-In Date: 2026-03-01");
    expect(slip).toContain("Check-Out Date: 2026-03-04");
    expect(slip).toContain("Number of Days: 3");
    expect(slip).toContain("AED 150.00");
    expect(slip).toContain("Please provide all necessary pet care instructions");
    expect(slip).toContain("Ensure vaccinations are up to date");
  });

  it("validates checkout date is after checkin date", () => {
    const checkInDate = "2026-03-04";
    const checkOutDate = "2026-03-02";

    const checkIn = new Date(checkInDate);
    const checkOut = new Date(checkOutDate);

    expect(checkOut.getTime() > checkIn.getTime()).toBe(false);
  });
});
