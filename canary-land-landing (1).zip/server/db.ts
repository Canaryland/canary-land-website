import { eq, and, gte, lt } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, groomingBookings, InsertGroomingBooking, petBoardingBookings, InsertPetBoardingBooking, payments, InsertPayment, emailNotifications, InsertEmailNotification, customers, InsertCustomer, customerPets, InsertCustomerPet, loyaltyPoints, InsertLoyaltyPoints, pointsTransactions, InsertPointsTransaction, redemptionOptions, InsertRedemptionOption } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Grooming Booking Queries
export async function createGroomingBooking(booking: InsertGroomingBooking) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  
  const result = await db.insert(groomingBookings).values(booking);
  return result;
}

export async function getGroomingBookingBySlipNumber(slipNumber: string) {
  const db = await getDb();
  if (!db) {
    return undefined;
  }
  
  const result = await db.select().from(groomingBookings).where(eq(groomingBookings.slipNumber, slipNumber)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllGroomingBookings() {
  const db = await getDb();
  if (!db) {
    return [];
  }
  
  const result = await db.select().from(groomingBookings).orderBy(groomingBookings.appointmentDate);
  return result;
}

export async function updateGroomingBookingStatus(slipNumber: string, status: string, whatsappSent?: Date) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  
  const updateData: Record<string, unknown> = { status };
  if (whatsappSent) {
    updateData.whatsappSent = whatsappSent;
  }
  
  await db.update(groomingBookings).set(updateData).where(eq(groomingBookings.slipNumber, slipNumber));
}

export async function updateGroomingBooking(slipNumber: string, updates: Record<string, unknown>) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  
  await db.update(groomingBookings).set(updates).where(eq(groomingBookings.slipNumber, slipNumber));
}

// Check if grooming time slot is available
export async function isGroomingTimeAvailable(date: Date, time: string) {
  const db = await getDb();
  if (!db) {
    return true;
  }
  
  const dateStart = new Date(date);
  dateStart.setHours(0, 0, 0, 0);
  const dateEnd = new Date(date);
  dateEnd.setHours(23, 59, 59, 999);
  
  const existingBookings = await db
    .select()
    .from(groomingBookings)
    .where(
      and(
        gte(groomingBookings.appointmentDate, dateStart),
        lt(groomingBookings.appointmentDate, dateEnd),
        eq(groomingBookings.appointmentTime, time),
      )
    );
  
  return existingBookings.length === 0;
}

// Pet Boarding Queries
export async function createPetBoardingBooking(booking: InsertPetBoardingBooking) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  
  const result = await db.insert(petBoardingBookings).values(booking);
  return result;
}

export async function getPetBoardingBookingBySlipNumber(slipNumber: string) {
  const db = await getDb();
  if (!db) {
    return undefined;
  }
  
  const result = await db.select().from(petBoardingBookings).where(eq(petBoardingBookings.slipNumber, slipNumber)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllPetBoardingBookings() {
  const db = await getDb();
  if (!db) {
    return [];
  }
  
  const result = await db.select().from(petBoardingBookings).orderBy(petBoardingBookings.checkInDate);
  return result;
}

export async function updatePetBoardingBooking(slipNumber: string, updates: Record<string, unknown>) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  
  await db.update(petBoardingBookings).set(updates).where(eq(petBoardingBookings.slipNumber, slipNumber));
}

// Check if boarding dates are available
export async function isPetBoardingDateAvailable(checkInDate: Date, checkOutDate: Date) {
  const db = await getDb();
  if (!db) {
    return true;
  }
  
  const conflictingBookings = await db
    .select()
    .from(petBoardingBookings)
    .where(
      and(
        lt(petBoardingBookings.checkInDate, checkOutDate),
        gte(petBoardingBookings.checkOutDate, checkInDate),
      )
    );
  
  return conflictingBookings.length === 0;
}

// Payment Queries
export async function createPayment(payment: InsertPayment) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  
  const result = await db.insert(payments).values(payment);
  return result;
}

export async function getPaymentByStripeId(stripePaymentIntentId: string) {
  const db = await getDb();
  if (!db) {
    return undefined;
  }
  
  const result = await db.select().from(payments).where(eq(payments.stripePaymentIntentId, stripePaymentIntentId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Email Notification Queries
export async function createEmailNotification(notification: any) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  
  const result = await db.insert(emailNotifications).values(notification);
  return result;
}

export async function getPendingEmailNotifications() {
  const db = await getDb();
  if (!db) {
    return [];
  }
  
  const result = await db.select().from(emailNotifications).where(eq(emailNotifications.status, "pending"));
  return result;
}

export async function updateEmailNotificationStatus(id: number, status: string, sentAt?: Date) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  
  const updateData: Record<string, unknown> = { status };
  if (sentAt) {
    updateData.sentAt = sentAt;
  }
  
  await db.update(emailNotifications).set(updateData).where(eq(emailNotifications.id, id));
}

// Customer Queries
export async function createOrUpdateCustomer(email: string, customerData: any) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  
  const existing = await db.select().from(customers).where(eq(customers.email, email)).limit(1);
  
  if (existing.length > 0) {
    await db.update(customers).set(customerData).where(eq(customers.email, email));
    return existing[0];
  } else {
    const result = await db.insert(customers).values({ ...customerData, email });
    return result;
  }
}

export async function getCustomerByEmail(email: string) {
  const db = await getDb();
  if (!db) {
    return undefined;
  }
  
  const result = await db.select().from(customers).where(eq(customers.email, email)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllCustomers() {
  const db = await getDb();
  if (!db) {
    return [];
  }
  
  const result = await db.select().from(customers).orderBy(customers.lastBookingDate);
  return result;
}

export async function getCustomerPets(customerId: number) {
  const db = await getDb();
  if (!db) {
    return [];
  }
  
  const result = await db.select().from(customerPets).where(eq(customerPets.customerId, customerId));
  return result;
}

export async function createCustomerPet(pet: any) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  
  const result = await db.insert(customerPets).values(pet);
  return result;
}

export async function updateCustomer(customerId: number, updates: Record<string, unknown>) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  
  await db.update(customers).set(updates).where(eq(customers.id, customerId));
}

// Loyalty Points Queries
export async function getOrCreateLoyaltyPoints(customerId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  
  const existing = await db.select().from(loyaltyPoints).where(eq(loyaltyPoints.customerId, customerId)).limit(1);
  
  if (existing.length > 0) {
    return existing[0];
  } else {
    const result = await db.insert(loyaltyPoints).values({
      customerId,
      currentBalance: 0,
      totalEarned: 0,
      totalRedeemed: 0,
    });
    return result;
  }
}

export async function addPoints(customerId: number, points: number, reason: string, bookingType?: string, bookingId?: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  
  // Update loyalty points balance
  const loyaltyResult = await getOrCreateLoyaltyPoints(customerId);
  const loyalty = await getLoyaltyPointsBalance(customerId);
  if (!loyalty) return;
  
  const newBalance = (loyalty.currentBalance || 0) + points;
  const newTotalEarned = (loyalty.totalEarned || 0) + points;
  
  await db.update(loyaltyPoints).set({
    currentBalance: newBalance,
    totalEarned: newTotalEarned,
    lastEarnedDate: new Date(),
  }).where(eq(loyaltyPoints.customerId, customerId));
  
  // Record transaction
  await db.insert(pointsTransactions).values({
    customerId,
    transactionType: "earned",
    points,
    reason,
    bookingType,
    bookingId,
    description: `Earned ${points} points for ${reason}`,
  });
}

export async function redeemPoints(customerId: number, points: number, reason: string) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  
  const loyalty = await getLoyaltyPointsBalance(customerId);
  if (!loyalty) {
    throw new Error("Loyalty points not found");
  }
  
  if ((loyalty.currentBalance || 0) < points) {
    throw new Error("Insufficient points balance");
  }
  
  const newBalance = (loyalty.currentBalance || 0) - points;
  const newTotalRedeemed = (loyalty.totalRedeemed || 0) + points;
  
  await db.update(loyaltyPoints).set({
    currentBalance: newBalance,
    totalRedeemed: newTotalRedeemed,
    lastRedeemedDate: new Date(),
  }).where(eq(loyaltyPoints.customerId, customerId));
  
  // Record transaction
  await db.insert(pointsTransactions).values({
    customerId,
    transactionType: "redeemed",
    points,
    reason,
    description: `Redeemed ${points} points for ${reason}`,
  });
}

export async function getLoyaltyPointsBalance(customerId: number) {
  const db = await getDb();
  if (!db) {
    return null;
  }
  
  const result = await db.select().from(loyaltyPoints).where(eq(loyaltyPoints.customerId, customerId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getPointsTransactionHistory(customerId: number) {
  const db = await getDb();
  if (!db) {
    return [];
  }
  
  const result = await db.select().from(pointsTransactions).where(eq(pointsTransactions.customerId, customerId)).orderBy(pointsTransactions.createdAt);
  return result;
}

export async function getRedemptionOptions() {
  const db = await getDb();
  if (!db) {
    return [];
  }
  
  const result = await db.select().from(redemptionOptions).where(eq(redemptionOptions.isActive, 1));
  return result;
}

export async function createRedemptionOption(option: any) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  
  const result = await db.insert(redemptionOptions).values(option);
  return result;
}

export async function updateRedemptionOption(optionId: number, updates: Record<string, unknown>) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  
  await db.update(redemptionOptions).set(updates).where(eq(redemptionOptions.id, optionId));
}


// Get customer by name
export async function getCustomerByName(name: string) {
  const db = await getDb();
  if (!db) {
    return null;
  }
  
  const result = await db.select().from(customers).where(eq(customers.name, name)).limit(1);
  return result.length > 0 ? result[0] : null;
}

// Get or create customer by name
export async function getOrCreateCustomerByName(name: string, phone: string, email?: string) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  
  // Try to find existing customer by name
  const existing = await getCustomerByName(name);
  if (existing) {
    return existing;
  }
  
  // Create new customer
  const result = await db.insert(customers).values({
    name,
    phone,
    email: email || `${name.toLowerCase().replace(/\s+/g, '.')}@canary-land.local`,
  });
  
  // Return the created customer
  const newCustomer = await getCustomerByName(name);
  return newCustomer;
}

// Get all customers with loyalty points
export async function getAllCustomersWithLoyaltyPoints() {
  const db = await getDb();
  if (!db) {
    return [];
  }
  
  const result = await db.select().from(customers);
  
  // Fetch loyalty points for each customer
  const customersWithPoints = await Promise.all(
    result.map(async (customer) => {
      const points = await getLoyaltyPointsBalance(customer.id);
      return {
        ...customer,
        loyaltyPoints: points || { currentBalance: 0, totalEarned: 0, totalRedeemed: 0 },
      };
    })
  );
  
  return customersWithPoints;
}
