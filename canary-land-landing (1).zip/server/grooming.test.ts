import { describe, expect, it } from "vitest";

// Helper to generate slip number
function generateSlipNumber(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  return `CL-${year}${month}${day}-${random}`;
}

describe("grooming booking logic", () => {
  it("generates valid slip numbers", () => {
    const slip1 = generateSlipNumber();
    const slip2 = generateSlipNumber();

    expect(slip1).toMatch(/^CL-\d{8}-\d{3}$/);
    expect(slip2).toMatch(/^CL-\d{8}-\d{3}$/);
    expect(slip1).not.toBe(slip2);
  });

  it("formats appointment slip correctly", () => {
    const slip = `
🐾 CANARY LAND GROOMING 🐾
Premium Pet Grooming & Boarding Services

📋 APPOINTMENT CONFIRMATION SLIP

Slip No: CL-20260212-001
Print Date: 12/02/2026 10:00:00 AM

⚡ CONFIRM: NO

APPOINTMENT DETAILS
Appointment Date: 2026-02-20
Appointment Time: 10:00
Status: Scheduled
Groomer: Ali

CUSTOMER INFORMATION
Customer Name: John Doe
Phone: +971501234567
Email: john@example.com

PET INFORMATION
Pet Name: Fluffy
Pet Type: Dog
Breed: Golden Retriever
Size: Large

SERVICE DETAILS
Service: Full Grooming

SPECIAL NOTES
Sensitive skin

⚠️ IMPORTANT NOTES:
- Extra charges apply for heavy matted coat condition
- We currently do not accept very aggressive pets
- Please arrive 10 minutes before appointment time
- Contact us for any changes or cancellations

Thank you for choosing Canary Land Pets! 🐾
    `;

    expect(slip).toContain("CANARY LAND GROOMING");
    expect(slip).toContain("John Doe");
    expect(slip).toContain("Fluffy");
    expect(slip).toContain("Golden Retriever");
    expect(slip).toContain("Extra charges apply for heavy matted coat condition");
    expect(slip).toContain("We currently do not accept very aggressive pets");
  });

  it("includes payment method in slip", () => {
    const slipOnline = `
💳 PAYMENT: Online (Stripe)
Please complete payment to confirm booking.
    `;

    const slipShop = `
💳 PAYMENT: At Shop
Payment due on arrival.
    `;

    expect(slipOnline).toContain("Online (Stripe)");
    expect(slipShop).toContain("At Shop");
  });

  it("validates appointment date and time format", () => {
    const appointmentDate = "2026-02-20";
    const appointmentTime = "10:00";

    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    const timeRegex = /^\d{2}:\d{2}$/;

    expect(appointmentDate).toMatch(dateRegex);
    expect(appointmentTime).toMatch(timeRegex);
  });
});
