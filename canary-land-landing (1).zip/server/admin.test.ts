import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return ctx;
}

describe("Admin Dashboard", () => {
  it("should fetch grooming bookings for authenticated admin", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const bookings = await caller.admin.getGroomingBookings();
    expect(Array.isArray(bookings)).toBe(true);
  });

  it("should fetch pet boarding bookings for authenticated admin", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const bookings = await caller.admin.getPetBoardingBookings();
    expect(Array.isArray(bookings)).toBe(true);
  });

  it("should update grooming booking status", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.updateGroomingBooking({
      slipNumber: "CL-20260212-001",
      status: "Confirmed",
      groomer: "Ali",
    });

    expect(result.success).toBe(true);
  });

  it("should update pet boarding booking status", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.updatePetBoardingBooking({
      slipNumber: "CL-20260212-002",
      status: "Confirmed",
    });

    expect(result.success).toBe(true);
  });

  it("should allow updating booking with special notes", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.updateGroomingBooking({
      slipNumber: "CL-20260212-003",
      specialNotes: "Customer requested extra care for matted coat",
    });

    expect(result.success).toBe(true);
  });
});
