import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { createGroomingBooking, updateGroomingBookingStatus, createPetBoardingBooking, isPetBoardingDateAvailable, isGroomingTimeAvailable, getAllGroomingBookings, getAllPetBoardingBookings, updateGroomingBooking, updatePetBoardingBooking, getCustomerByName, getOrCreateCustomerByName, addPoints, getLoyaltyPointsBalance, getAllCustomersWithLoyaltyPoints } from "./db";
import axios from "axios";

// Helper function to generate slip number
function generateSlipNumber(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  return `CL-${year}${month}${day}-${random}`;
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  grooming: router({
    checkAvailability: publicProcedure
      .input(z.object({
        date: z.string(),
        time: z.string(),
      }))
      .query(async ({ input }) => {
        try {
          const available = await isGroomingTimeAvailable(new Date(input.date), input.time);
          return { available };
        } catch (error) {
          console.error("[Grooming] Availability check failed:", error);
          return { available: true };
        }
      }),

    createBooking: publicProcedure
      .input(z.object({
        customerName: z.string(),
        customerPhone: z.string(),
        customerEmail: z.string().optional(),
        petName: z.string(),
        petType: z.string(),
        petBreed: z.string().optional(),
        petSize: z.string(),
        service: z.string(),
        appointmentDate: z.string(),
        appointmentTime: z.string(),
        groomer: z.string().optional(),
        specialNotes: z.string().optional(),
        paymentMethod: z.enum(["online", "shop"]).optional(),
      }))
      .mutation(async ({ input }) => {
        try {
          // Check availability
          const available = await isGroomingTimeAvailable(new Date(input.appointmentDate), input.appointmentTime);
          if (!available) {
            throw new Error("This time slot is already booked. Please choose another time.");
          }

          // Generate slip number
          const slipNumber = generateSlipNumber();
          
          // Create booking in database
          await createGroomingBooking({
            slipNumber,
            customerName: input.customerName,
            customerPhone: input.customerPhone,
            customerEmail: input.customerEmail,
            petName: input.petName,
            petType: input.petType,
            petBreed: input.petBreed,
            petSize: input.petSize,
            service: input.service,
            appointmentDate: new Date(input.appointmentDate),
            appointmentTime: input.appointmentTime,
            groomer: input.groomer,
            specialNotes: input.specialNotes,
            status: "Scheduled",
          });

          // Format the appointment slip message
          const paymentInfo = input.paymentMethod === "online" 
            ? "\n💳 PAYMENT: Online (Stripe)\nPlease complete payment to confirm booking."
            : "\n💳 PAYMENT: At Shop\nPayment due on arrival.";

          const appointmentSlip = `
🐾 CANARY LAND GROOMING 🐾
Premium Pet Grooming & Boarding Services

📋 APPOINTMENT CONFIRMATION SLIP

Slip No: ${slipNumber}
Print Date: ${new Date().toLocaleDateString('en-GB')} ${new Date().toLocaleTimeString('en-US')}

⚡ CONFIRM: NO

APPOINTMENT DETAILS
Appointment Date: ${input.appointmentDate}
Appointment Time: ${input.appointmentTime}
Status: Scheduled
Groomer: ${input.groomer || 'To be assigned'}

CUSTOMER INFORMATION
Customer Name: ${input.customerName}
Phone: ${input.customerPhone}
Email: ${input.customerEmail || 'N/A'}

PET INFORMATION
Pet Name: ${input.petName}
Pet Type: ${input.petType}
Breed: ${input.petBreed || 'Not specified'}
Size: ${input.petSize}

SERVICE DETAILS
Service: ${input.service}

SPECIAL NOTES
${input.specialNotes || 'None'}

⚠️ IMPORTANT NOTES:
- Extra charges apply for heavy matted coat condition
- We currently do not accept very aggressive pets
- Please arrive 10 minutes before appointment time
- Contact us for any changes or cancellations
${paymentInfo}

Thank you for choosing Canary Land Pets! 🐾
          `;

          // Booking is now registered in the admin dashboard
          await updateGroomingBookingStatus(slipNumber, "Confirmed", new Date());

          return {
            success: true,
            slipNumber,
            message: "Booking confirmed! Your appointment has been registered in our system.",
            appointmentSlip,
          };
        } catch (error) {
          console.error("[Grooming] Booking creation failed:", error);
          throw new Error(error instanceof Error ? error.message : "Failed to create booking. Please try again.");
        }
      }),
  }),

  boarding: router({
    checkAvailability: publicProcedure
      .input(z.object({
        checkInDate: z.string(),
        checkOutDate: z.string(),
      }))
      .query(async ({ input }) => {
        try {
          const available = await isPetBoardingDateAvailable(new Date(input.checkInDate), new Date(input.checkOutDate));
          return { available };
        } catch (error) {
          console.error("[Boarding] Availability check failed:", error);
          return { available: true };
        }
      }),

    createBooking: publicProcedure
      .input(z.object({
        customerName: z.string(),
        customerPhone: z.string(),
        customerEmail: z.string().optional(),
        petName: z.string(),
        petType: z.string(),
        petBreed: z.string().optional(),
        petSize: z.string(),
        checkInDate: z.string(),
        checkOutDate: z.string(),
        specialNotes: z.string().optional(),
        paymentMethod: z.enum(["online", "shop"]).optional(),
      }))
      .mutation(async ({ input }) => {
        try {
          // Check availability
          const available = await isPetBoardingDateAvailable(new Date(input.checkInDate), new Date(input.checkOutDate));
          if (!available) {
            throw new Error("These dates are not available. Please choose different dates.");
          }

          // Calculate number of days
          const checkIn = new Date(input.checkInDate);
          const checkOut = new Date(input.checkOutDate);
          const numberOfDays = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24));
          
          if (numberOfDays <= 0) {
            throw new Error("Check-out date must be after check-in date.");
          }

          // Calculate total price (AED 50 per day = 5000 fils)
          const pricePerDay = 5000; // AED 50 in fils
          const totalPrice = numberOfDays * pricePerDay;

          // Generate slip number
          const slipNumber = generateSlipNumber();
          
          // Create booking in database
          await createPetBoardingBooking({
            slipNumber,
            customerName: input.customerName,
            customerPhone: input.customerPhone,
            customerEmail: input.customerEmail,
            petName: input.petName,
            petType: input.petType,
            petBreed: input.petBreed,
            petSize: input.petSize,
            checkInDate: checkIn,
            checkOutDate: checkOut,
            numberOfDays,
            pricePerDay,
            totalPrice,
            specialNotes: input.specialNotes,
            status: "Pending",
          });

          // Format the booking slip message
          const totalPriceAED = (totalPrice / 100).toFixed(2);
          const paymentInfo = input.paymentMethod === "online" 
            ? "\n💳 PAYMENT: Online (Stripe)\nPlease complete payment to confirm booking."
            : "\n💳 PAYMENT: At Shop\nPayment due on check-in.";

          const bookingSlip = `
🐾 CANARY LAND PET BOARDING 🐾
Premium Pet Boarding Services

📋 BOOKING CONFIRMATION SLIP

Slip No: ${slipNumber}
Print Date: ${new Date().toLocaleDateString('en-GB')} ${new Date().toLocaleTimeString('en-US')}

⚡ STATUS: PENDING

BOOKING DETAILS
Check-In Date: ${input.checkInDate}
Check-Out Date: ${input.checkOutDate}
Number of Days: ${numberOfDays}
Status: Pending Confirmation

CUSTOMER INFORMATION
Customer Name: ${input.customerName}
Phone: ${input.customerPhone}
Email: ${input.customerEmail || 'N/A'}

PET INFORMATION
Pet Name: ${input.petName}
Pet Type: ${input.petType}
Breed: ${input.petBreed || 'Not specified'}
Size: ${input.petSize}

PRICING DETAILS
Price Per Day: AED 50
Number of Days: ${numberOfDays}
Total Price: AED ${totalPriceAED}

SPECIAL NOTES
${input.specialNotes || 'None'}

⚠️ IMPORTANT NOTES:
- Please provide all necessary pet care instructions
- Ensure vaccinations are up to date
- Bring any required medications or special food
- We provide comfortable accommodation and daily care
${paymentInfo}

Thank you for choosing Canary Land Pets! 🐾
          `;

          // Booking is now registered in the admin dashboard
          return {
            success: true,
            slipNumber,
            numberOfDays,
            totalPrice: totalPriceAED,
            message: "Booking request submitted! Your booking has been registered in our system.",
            bookingSlip,
          };
        } catch (error) {
          console.error("[Boarding] Booking creation failed:", error);
          throw new Error(error instanceof Error ? error.message : "Failed to create booking. Please try again.");
        }
      }),
  }),

  admin: router({
    getGroomingBookings: protectedProcedure
      .query(async () => {
        try {
          const bookings = await getAllGroomingBookings();
          return bookings;
        } catch (error) {
          console.error("[Admin] Failed to fetch grooming bookings:", error);
          throw new Error("Failed to fetch grooming bookings");
        }
      }),

    getPetBoardingBookings: protectedProcedure
      .query(async () => {
        try {
          const bookings = await getAllPetBoardingBookings();
          return bookings;
        } catch (error) {
          console.error("[Admin] Failed to fetch pet boarding bookings:", error);
          throw new Error("Failed to fetch pet boarding bookings");
        }
      }),

    updateGroomingBooking: protectedProcedure
      .input(z.object({
        slipNumber: z.string(),
        status: z.string().optional(),
        groomer: z.string().optional(),
        specialNotes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        try {
          const updates: Record<string, unknown> = {};
          if (input.status) updates.status = input.status;
          if (input.groomer) updates.groomer = input.groomer;
          if (input.specialNotes) updates.specialNotes = input.specialNotes;
          
          await updateGroomingBooking(input.slipNumber, updates);
          return { success: true };
        } catch (error) {
          console.error("[Admin] Failed to update grooming booking:", error);
          throw new Error("Failed to update booking");
        }
      }),

    updatePetBoardingBooking: protectedProcedure
      .input(z.object({
        slipNumber: z.string(),
        status: z.string().optional(),
        specialNotes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        try {
          const updates: Record<string, unknown> = {};
          if (input.status) updates.status = input.status;
          if (input.specialNotes) updates.specialNotes = input.specialNotes;
          
          await updatePetBoardingBooking(input.slipNumber, updates);
          return { success: true };
        } catch (error) {
          console.error("[Admin] Failed to update pet boarding booking:", error);
          throw new Error("Failed to update booking");
        }
      }),

    awardPoints: protectedProcedure
      .input(z.object({
        customerName: z.string(),
        points: z.number().min(1),
        reason: z.string(),
      }))
      .mutation(async ({ input }) => {
        try {
          // Get or create customer
          const customer = await getOrCreateCustomerByName(input.customerName, "", undefined);
          if (!customer) {
            throw new Error("Customer not found");
          }

          // Award points
          await addPoints(customer.id, input.points, input.reason);

          // Get updated balance
          const updatedBalance = await getLoyaltyPointsBalance(customer.id);

          return {
            success: true,
            message: `Awarded ${input.points} points to ${input.customerName}`,
            newBalance: updatedBalance?.currentBalance || 0,
          };
        } catch (error) {
          console.error("[Admin] Failed to award points:", error);
          throw new Error(error instanceof Error ? error.message : "Failed to award points");
        }
      }),

    getAllCustomersWithPoints: protectedProcedure
      .query(async () => {
        try {
          const customersWithPoints = await getAllCustomersWithLoyaltyPoints();
          return customersWithPoints;
        } catch (error) {
          console.error("[Admin] Failed to fetch customers with points:", error);
          throw new Error("Failed to fetch customers");
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
